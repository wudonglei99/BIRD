from socket import *
import threading
import time

import numpy as np

address='0.0.0.0'
port=2222
buffsize=1024
s = socket(AF_INET, SOCK_STREAM)
s.bind((address,port))
s.listen(5)     #最大连接数
data = []

class MyThread(threading.Thread):
    def __init__(self, signal,clientsock,clientaddress):
        threading.Thread.__init__(self)
        self.signal = signal
        self.sock = clientsock
        self.addr = clientaddress

    def run(self):
        tmp = self.sock.recv(buffsize)
        recvdata = int.from_bytes(tmp, byteorder='little', signed=True)
        print("接收来自",self.addr,"的数据：",recvdata)
        data.append(recvdata)
        print("q_data：" ,data)
        self.signal.wait()
        print( "sent back",data )
        self.sock.send(int(np.sum(data)).to_bytes(2, 'little'))


if __name__ == "__main__":
    signal = threading.Event()
    for t in range(3):
        clientsock,clientaddress=s.accept()
        print('connect from:',clientaddress)
        thread = MyThread(signal,clientsock,clientaddress)
        thread.start()
    time.sleep(0.1)
    if len(data)==3:
        signal.set()