# -*- coding: UTF-8 -*-
# @Time : 2022/4/7 17:54
# @File : ulits.py
# @Software: PyCharm

# -*- coding: UTF-8 -*-
# @Time : 2022/4/7 17:49
# @File : ulit.py
# @Software: PyCharm
import time

import torch
import numpy as np
from itertools import chain

def get_shape(shape_1d,dim_size):
    start = 0; shape_list = []
    for d in dim_size:
        shape_list.append(shape_1d[start:start+d])
        start = start+d
    return shape_list

def tensor_layer_num(shape_list):
    i = 0;bias_bn = [];bb=0
    for id, item in enumerate(shape_list):
        if len(item)!=1:
            if id!=0:
                bias_bn.append(bb)
            bb=0
            i+=1  # 記錄有多少非 bb   layer
        else:
            bb+=1
        if id ==len(shape_list)-1:
            bias_bn.append(bb)
    return i,bias_bn


def get_interval(flatten_list):
    sum = 0; interval = []
    for l in flatten_list:
        sum += l
        interval.append(sum)
    return interval

# def idx_container(interval,shape_list,device):  # kernel
#     layer_idx = []; start = 0; chunk_idx = []
#     for i in range(len(interval)):
#         layer_idx.append(torch.tensor(list(range(start,interval[i])),device=device))
#         start = interval[i]
#     for j, layer in enumerate(layer_idx):
#         layer_with_chunk = []
#         if len(shape_list[j])!=1:
#             if len(shape_list[j])==4:
#                 chunk_len = np.prod(np.array(shape_list[j])[2:])
#                 for k in range(shape_list[j][0]*shape_list[j][1]):
#                     layer_with_chunk.append(layer[k*chunk_len:(k+1)*chunk_len])
#             else:
#                 chunk_len = np.prod(np.array(shape_list[j])[1])
#                 for k in range(shape_list[j][0]):
#                     layer_with_chunk.append(layer[k*chunk_len:(k+1)*chunk_len])
#         else:
#             layer_with_chunk.append(layer)
#         chunk_idx.append(layer_with_chunk)
#     return chunk_idx

def idx_container(interval,shape_list,device):   # filter
    layer_idx = []; start = 0; chunk_idx = []
    for i in range(len(interval)):
        layer_idx.append(torch.tensor(list(range(start,interval[i])),device=device))
        start = interval[i]
    for j, layer in enumerate(layer_idx):
        layer_with_chunk = []
        if len(shape_list[j])!=1:
            chunk_len = np.prod(np.array(shape_list[j])[1:])
            for k in range(shape_list[j][0]):
                layer_with_chunk.append(layer[k*chunk_len:(k+1)*chunk_len])
        else:
            layer_with_chunk.append(layer)
        chunk_idx.append(layer_with_chunk)
    return chunk_idx

def get_all(idx,layer_num,chunk_idx,bias_bn):
    start = 0; tmp = []; i=0;k=0
    for num in layer_num:
        w = list(np.array(chunk_idx[i])[idx[start:start + num]])
        i+=1
        for j in range(bias_bn[k]):
            w.append(chunk_idx[i+j][0][idx[start:start+num]])
            # w.append(chunk_idx[i+j][0][np.floor(idx[start:start+num]/(len(chunk_idx[i-1])/len(chunk_idx[i][0])))])
        tmp.append(w)
        start=start+num
        i+=bias_bn[k]
        k+=1
    tmp = (list(chain.from_iterable(tmp)))
    all_idx = torch.cat((tmp[0],tmp[1]), dim=0)
    for item in tmp[2:]:
        all_idx = torch.cat((all_idx,item), dim=0)
    return all_idx





# def get_all(idx,layer_num,chunk_idx):
#     ss = time.clock()
#     start = 0; tmp = []; i=0
#     for num in layer_num:
#         w = list(np.array(chunk_idx[i * 2])[idx[start:start + num]])
#         w.append(chunk_idx[i*2+1][0][idx[start:start+num]])
#         tmp.append(w)
#         start=start+num;       i+=1
#     tmp = (list(chain.from_iterable(tmp)))
#     all_idx = torch.cat((tmp[0],tmp[1]), dim=0)
#     for item in tmp[2:]:
#         all_idx = torch.cat((all_idx,item), dim=0)
#     print('xxx',time.clock()-ss)
#     return all_idx





#
# def get_all(idx,layer_num,chunk_idx):
#     s = time.time()
#     start = 0; tmp = []; i=0
#     for num in layer_num:
#         tmp.append(torch.tensor(np.array(chunk_idx[i*2])[idx[start:start+num]]))
#         tmp.append(torch.tensor(np.array(chunk_idx[i*2+1][0])[idx[start:start+num]]))
#         start=start+num;       i+=1
#     all_idx = torch.cat((torch.flatten(tmp[0]), torch.flatten(tmp[1])), 0)
#     for j in range(2, len(tmp)):
#         all_idx = torch.cat((all_idx, torch.flatten(tmp[j])), dim=0)
#     all_idx = all_idx.cpu().numpy()
#     print(time.time()-s)
#     return all_idx
