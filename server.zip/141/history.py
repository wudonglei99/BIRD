# -*- coding: UTF-8 -*-
# @Time : 2022/4/21 16:31
# @File : history.py
# @Software: PyCharm
#
# import time
# from socket import *
# import struct
# from quan import sq,block_sq,qd,mq
# address='10.249.41.141'   #服务器的ip地址
# s=socket(AF_INET, SOCK_STREAM)
# from math import floor,ceil
# import torch
# import numpy as np
# from itertools import chain
# import random
# from torch.utils.data.sampler import WeightedRandomSampler
#
#
# def get_num_correct(out, labels):  #求准确率
#     return out.argmax(dim=1).eq(labels).sum().item()
#
# def shape_1d(shape_list):
#     shape_1d = []; dim_size = []
#     for dim in shape_list:
#         dim_size.append(len(dim))
#         for item in dim:
#             shape_1d.append(item)
#     return dim_size, shape_1d
#
#
#
# def get_interval(flatten_list):
#     sum = 0; interval = []
#     for l in flatten_list:
#         sum += l
#         interval.append(sum)
#     return interval
#
# def vec2net(vec, shape_list):
#     k = 0
#     net = []
#     for item in shape_list:
#         temp = 1
#         for _ in range(len(item)):
#             temp *= item[_]
#         param_1D = vec[k:k + temp]
#         param = torch.reshape(param_1D, item)
#         net.append(param)
#         k += temp
#     return net
#
# def net2vec(model):
#     model_1d = []
#     for layer in model.parameters():
#         layer_1d = torch.flatten(layer.data)
#         model_1d.append(layer_1d)
#     out = torch.cat((model_1d[0],model_1d[1]),0)
#     for j in range(2,len(model_1d)):
#         out = torch.cat((out, model_1d[j]), dim=0)
#     return out
#
# def idx_container(interval,shape_list,device):
#     layer_idx = []; start = 0; chunk_idx = []
#     for i in range(len(interval)):
#         layer_idx.append(torch.tensor(list(range(start,interval[i])),device=device))
#         start = interval[i]
#     for j, layer in enumerate(layer_idx):
#         layer_with_chunk = []
#         if len(shape_list[j])!=1:
#             chunk_len = np.prod(np.array(shape_list[j])[1:])
#             for k in range(shape_list[j][0]):
#                 layer_with_chunk.append(layer[k*chunk_len:(k+1)*chunk_len])
#         else:
#             layer_with_chunk.append(layer)
#         chunk_idx.append(layer_with_chunk)
#     return chunk_idx
#
# def get_all(idx,layer_num,chunk_idx):
#     start = 0; tmp = []; i=0
#     for num in layer_num:
#         w = list(np.array(chunk_idx[i * 2])[idx[start:start + num]])
#         w.append(chunk_idx[i*2+1][0][idx[start:start+num]])
#         tmp.append(w)
#         start=start+num;       i+=1
#     tmp = (list(chain.from_iterable(tmp)))
#     all_idx = torch.cat((tmp[0],tmp[1]), dim=0)
#     for item in tmp[2:]:
#         all_idx = torch.cat((all_idx,item), dim=0)
#     return all_idx
#
# def net_split(DwR_1d,shape_list):
#     DwR = vec2net(DwR_1d, shape_list)
#     conv = []; fc = []; bias = []
#     for layer in DwR:
#         if len(layer.data.shape)==4:   conv.append(torch.flatten(layer.data,start_dim=1))
#         elif len(layer.data.shape)==2: fc.append(layer.data)
#         else:                          bias.append(layer.data)
#     return [conv, fc,bias]
#
# def statistical(idx,interval):
#     layer_in = np.zeros(len(interval))
#     for i in idx:
#         for j in range(len(interval)):
#             if interval[j]< i <interval[j+1] or 0 < i <interval[j]:
#                 layer_in[j]+=int(1)
#                 break
#     return layer_in
#
# def smartidx(DwR_1d,splited_DwR, sr,leng, chunk_idx):
#     var_abs = torch.abs(DwR_1d); n = 0
#     _, topk_1d = torch.topk(var_abs, floor(sr * leng))
#     topk_1d = set(topk_1d.cpu().numpy().tolist())
#     conv_chunk = chunk_idx[:2*len(splited_DwR[0])]
#
#     for layer in range(len(splited_DwR[0])):
#         n+=torch.prod(torch.tensor(splited_DwR[0][layer].shape))
#     conv_idx_list = set(list(range(n)))
#     conv_param=conv_idx_list.intersection(topk_1d)
#     fc_idx = torch.tensor(list(topk_1d-conv_param),device="cuda:0")
#
#     layer_num = []; conv_idx = []
#     for layer in conv_chunk:
#         id_list=[]
#         if len(layer)!=1:
#             for id, filter in enumerate(layer):
#                 filter = set(filter.cpu().numpy())
#                 if len(filter.intersection(conv_param))!=0:
#                     id_list.append(id)
#             conv_idx.append(id_list);layer_num.append(len(id_list))
#     conv_idx = list(chain.from_iterable(conv_idx))
#
#     all_conv_idx = get_all(conv_idx, layer_num, chunk_idx)
#     all_idx = torch.cat((all_conv_idx,fc_idx),0)
#     value = DwR_1d[all_idx]
#     uploaded_idx = torch.cat((torch.tensor(conv_idx,device="cuda:0"),fc_idx),0)
#     return uploaded_idx, value, layer_num, len(conv_idx)
#
# def chunk_selection(splited_DwR,sr):
#     selected_filter = []; selected_chunk = []; selected_bias = []; conv_idx = []; fc_idx = []; layer_num = [];st=0
#     for i,conv_layer in enumerate(splited_DwR[0]):
#         # idx = torch.randint(high=len(conv_layer), size=(ceil(sr * len(conv_layer)),), device="cuda:0") # 快  重复(重复率高)
#         idx = torch.tensor(random.sample(list(range(len(conv_layer))), ceil(sr * len(conv_layer))))
#         idx,_ = torch.sort(idx)
#         if len(idx)==0: layer_num.append(0)
#         else:
#             selected_filter.append(conv_layer[idx])
#             selected_bias.append(splited_DwR[2][i][idx])
#             conv_idx.append(idx); layer_num.append(len(idx))#; layer_num.append(len(idx))
#     for i,fc_layer in enumerate(splited_DwR[1]):
#         # idx = torch.randint(high=len(fc_layer), size=(ceil(sr * len(fc_layer)),), device="cuda:0")   # 快  重复(重复率高)
#         idx = torch.tensor(random.sample(list(range(len(fc_layer))), ceil(sr * len(fc_layer))))
#         idx, _ = torch.sort(idx)
#         if len(idx) == 0: layer_num.append(0)
#         else:
#             selected_chunk.append(fc_layer[idx])
#             selected_bias.append(splited_DwR[2][i+len(splited_DwR[0])][idx])
#             fc_idx.append(idx); layer_num.append(len(idx))#; layer_num.append(len(idx))
#     group_idx = conv_idx+fc_idx
#     idx_1d = torch.cat((group_idx[0], group_idx[1]), 0)
#     for j in range(2, len(group_idx)):
#         idx_1d = torch.cat((idx_1d, group_idx[j]), dim=0)
#
#     selected_param = list(chain.from_iterable(zip(selected_filter + selected_chunk, selected_bias)))
#
#     selected_param,st_list = block_sq(selected_param)  # block_sq
#
#     value_1d = torch.cat((torch.flatten(selected_param[0]), torch.flatten(selected_param[1])), 0)
#     for j in range(2, len(selected_param)):
#         value_1d = torch.cat((value_1d, torch.flatten(selected_param[j])), dim=0)
#
#     value_1d = value_1d.type(torch.int8)                # block_sq
#     st_list = torch.tensor(st_list, device="cuda:0")    # block_sq
#     return idx_1d,[st_list,value_1d],layer_num          # block_sq
#
#     # return idx_1d, value_1d, layer_num                # sq
#
# def chunk_selection2(splited_DwR,sr):
#     st_list_q=[]; st_list_s=[]; selected_block=[];selected_bias=[]; block_idx = []; layer_num=[]
#     for i,block_layer in enumerate(splited_DwR[0]+splited_DwR[1]):
#         '''第一次随机量化'''
#         norm_list = []
#         for block in block_layer:
#             norm_list.append(torch.norm(torch.abs(block), p=2))
#         norm_list = torch.tensor(norm_list,device="cuda:0")
#         s_t =  torch.max(norm_list);      st_list_q.append(s_t/np.sqrt(block_layer.shape[1]))
#         prob_1 =  norm_list / s_t
#         prob_0 = 1 - prob_1
#         prob = torch.t(torch.vstack((prob_0, prob_1))).cpu().numpy()
#         bi = list(WeightedRandomSampler(prob, 1))
#         bi = torch.tensor(np.reshape(bi, [len(bi), ]),device="cuda:0")
#         big_norm_idx = torch.where(bi>0)[0]
#         '''第二次随机稀疏化'''
#         if len(big_norm_idx) > ceil(sr * len(block_layer)):
#             IdxOfIdx = torch.tensor(random.sample(list(range(len(big_norm_idx))), ceil(sr * len(block_layer))))
#             idx = big_norm_idx[IdxOfIdx]
#         else:
#             idx = big_norm_idx
#         st_list_s.append(1/(len(idx)/len(big_norm_idx)))
#         if len(idx) == 0:
#             layer_num.append(0)
#         else:
#             idx, _ = torch.sort(idx)
#             selected_block.append(block_layer[idx])
#             selected_bias.append(splited_DwR[2][i][idx])
#             block_idx.append(idx); layer_num.append(len(idx))#; layer_num.append(len(idx))
#     '''获取实际上传索引'''
#     idx_1d = torch.cat((block_idx[0], block_idx[1]), 0)
#     for j in range(2, len(block_idx)):
#         idx_1d = torch.cat((idx_1d, block_idx[j]), dim=0)
#     '''获取实际上传参数值'''
#     selected_param = list(chain.from_iterable(zip(selected_block, selected_bias)))
#     selected_param_sign=[]
#     for item in selected_param:
#         selected_param_sign.append(torch.sign(item))
#     st_list = st_list_s*np.array(st_list_q)
#     st_list = list(chain.from_iterable(zip(st_list, st_list)))
#
#     value_1d = torch.cat((torch.flatten(selected_param_sign[0]), torch.flatten(selected_param_sign[1])), 0)
#     for j in range(2, len(selected_param_sign)):
#         value_1d = torch.cat((value_1d, torch.flatten(selected_param_sign[j])), dim=0)
#
#     value_1d = value_1d.type(torch.int8)
#     st_list = torch.tensor(st_list, device="cuda:0")
#     return idx_1d,[st_list,value_1d],layer_num
#
#
# def sparsification(DwR_1d,leng,sr,s_flag,splited_DwR,chunk_idx):
#     layer_num = [];conv_idx_num=0
#     if s_flag == 0:
#         var_abs = torch.abs(DwR_1d)
#         _,idx = torch.topk(var_abs,floor(sr*leng))
#         value = DwR_1d[idx]     # topk不用乘(1/(sr*2))，有偏 ！
#     elif s_flag==1:
#         idx = torch.randint(high = leng, size = (floor(sr*leng),),device ="cuda:0")  # 快  重复(重复率低)
#         # idx = torch.tensor(random.sample(list(range(leng)), floor(sr * leng)))     # 慢  无重复
#         value = DwR_1d[idx]*(1/(sr*2))
#     elif s_flag==2:
#         idx,value,layer_num = chunk_selection(splited_DwR,sr)
#         value *= (1 / (len(value)/leng * 2))
#     else:
#         idx, value, layer_num, conv_idx_num = smartidx(DwR_1d,splited_DwR, sr,leng,chunk_idx)
#     return idx,value,layer_num,conv_idx_num
#
#
# def process(Delta_1d,leng,num_layer,q_res,q_flag,s_flag, sr, splited_delta,chunk_idx):
#     sparse_cost, code_cost, mq_cost,conv_idx_num = 0,0,0,0; pack_cost,layer_num=[],[]; idx = list(range(leng)); idx_byte=0
#     q_res_new = np.zeros(leng)
#     if sr!=1:
#         s_sparse = time.clock();idx,value,layer_num,conv_idx_num = sparsification(Delta_1d,leng,sr,s_flag,splited_delta,chunk_idx); sparse_cost = round(time.clock() - s_sparse,3)
#         value = value.cpu().numpy(); idx = idx.cpu().numpy()
#         s_pack = time.clock(); idx_byte = struct.pack(('%dI' % len(idx)), *idx); pack_cost.append(time.clock() - s_pack)
#         # s_code = time.clock(); idx_byte = lzma.compress(idx_byte);code_cost = round(time.clock() - s_code,3)
#     else:
#         value = Delta_1d.cpu().numpy()    # 无稀疏化
#
#     if   q_flag==0:
#         s_pack = time.clock();uploaded = struct.pack(('%df' % len(value)), *value); pack_cost.append(time.clock() - s_pack)
#     elif q_flag==1:  # https://docs.python.org/3/library/struct.html#format-characters
#         if s_flag==2 and int(sr)!=1:    all_idx = get_all(idx, layer_num, chunk_idx).cpu()
#         elif s_flag==3 and int(sr)!=1:  all_idx = np.hstack((get_all(idx[:conv_idx_num], layer_num, chunk_idx).cpu().numpy(), idx[conv_idx_num:]))
#         else:            all_idx = idx
#         s_mq = time.clock(); sign, mean, q_res_new = sq(q_res,value,q_res_new,all_idx); mq_cost = round(time.clock() - s_mq,3)
#         s_pack = time.clock();uploaded = struct.pack('f', mean) + struct.pack(('%db' % len(sign)), *sign);pack_cost.append(time.clock() - s_pack)
#     else:
#         uploaded = qd(Delta_1d,num_layer,8)
#
#     if idx_byte:
#         uploaded+=idx_byte
#     compress_cost = [sparse_cost, mq_cost, code_cost, round(sum(pack_cost),3)]
#     return uploaded,q_res_new,compress_cost,idx,layer_num,conv_idx_num
#
#
# def rb(leng, sr, splited_delta):
#     sparse_cost, code_cost, mq_cost, conv_idx_num = 0, 0, 0, 0; pack_cost, layer_num = [], []
#     q_res_new = np.zeros(leng)
#
#     s_sparse = time.clock()
#     idx, value, layer_num = chunk_selection2(splited_delta, sr)
#     sparse_cost = round(time.clock() - s_sparse, 3)
#     '''block sq'''
#     st_list = value[0]
#     Tern_value = value[1]
#     Tern_value = Tern_value.cpu().numpy(); st_list = st_list.cpu().numpy(); idx = idx.cpu().numpy()
#     s_pack = time.clock(); idx_byte = struct.pack(('%dI' % len(idx)), *idx); pack_cost.append(time.clock() - s_pack)
#     s_pack = time.clock()
#     uploaded = struct.pack('%df' % len(st_list), *st_list) + struct.pack(('%db' % len(Tern_value)), *Tern_value)
#     pack_cost.append(time.clock() - s_pack)
#     '''sq'''
#     # s_pack = time.clock(); idx_byte = struct.pack(('%dI' % len(idx)), *idx); pack_cost.append(time.clock() - s_pack)
#     # value = value.cpu().numpy();  idx = idx.cpu().numpy()             # sq
#     # all_idx = get_all(idx, layer_num, chunk_idx).cpu()                # sq
#     # sign, mean, q_res_new = sq(q_res, value, q_res_new, all_idx)      # sq
#     # uploaded = struct.pack('f', mean) + struct.pack(('%db' % len(sign)), *sign)  # sq
#     '”“不量化'
#     # s_pack = time.clock(); idx_byte = struct.pack(('%dI' % len(idx)), *idx); pack_cost.append(time.clock() - s_pack)
#     # value *= (1 / (len(value) / leng * 2))
#     # value = value.cpu().numpy();      idx = idx.cpu().numpy()  # sq
#     # uploaded = struct.pack(('%df' % len(value)), *value)  # sq
#
#     uploaded += idx_byte
#     compress_cost = [sparse_cost, mq_cost, code_cost, round(sum(pack_cost), 3)]
#     return uploaded, q_res_new, compress_cost, idx, layer_num







# def chunk_selection(splited_DwR,sr):
#     selected_filter = []; selected_chunk = []; selected_bias = []; conv_idx = []; fc_idx = []; layer_num = [];st=0
#     for i,conv_layer in enumerate(splited_DwR[0]):
#         # idx = torch.randint(high=len(conv_layer), size=(ceil(sr * len(conv_layer)),), device="cuda:0") # 快  重复(重复率高)
#         idx = torch.tensor(random.sample(list(range(len(conv_layer))), ceil(sr * len(conv_layer))))
#         idx,_ = torch.sort(idx)
#         if len(idx)==0: layer_num.append(0)
#         else:
#             selected_filter.append(conv_layer[idx])
#             selected_bias.append(splited_DwR[2][i][idx])
#             conv_idx.append(idx); layer_num.append(len(idx))#; layer_num.append(len(idx))
#     for i,fc_layer in enumerate(splited_DwR[1]):
#         # idx = torch.randint(high=len(fc_layer), size=(ceil(sr * len(fc_layer)),), device="cuda:0")   # 快  重复(重复率高)
#         idx = torch.tensor(random.sample(list(range(len(fc_layer))), ceil(sr * len(fc_layer))))
#         idx, _ = torch.sort(idx)
#         if len(idx) == 0: layer_num.append(0)
#         else:
#             selected_chunk.append(fc_layer[idx])
#             selected_bias.append(splited_DwR[2][i+len(splited_DwR[0])][idx])
#             fc_idx.append(idx); layer_num.append(len(idx))#; layer_num.append(len(idx))
#     group_idx = conv_idx+fc_idx
#     idx_1d = torch.cat((group_idx[0], group_idx[1]), 0)
#     for j in range(2, len(group_idx)):
#         idx_1d = torch.cat((idx_1d, group_idx[j]), dim=0)
#
#     selected_param = list(chain.from_iterable(zip(selected_filter + selected_chunk, selected_bias)))
#
#     selected_param,st_list = block_sq(selected_param)  # block_sq
#
#     value_1d = torch.cat((torch.flatten(selected_param[0]), torch.flatten(selected_param[1])), 0)
#     for j in range(2, len(selected_param)):
#         value_1d = torch.cat((value_1d, torch.flatten(selected_param[j])), dim=0)
#
#     value_1d = value_1d.type(torch.int8)                # block_sq
#     st_list = torch.tensor(st_list, device="cuda:0")    # block_sq
#     return idx_1d,[st_list,value_1d],layer_num          # block_sq
#
#     # return idx_1d, value_1d, layer_num                # sq






# import time
# from socket import *
# import struct
# import argparse
# address='10.249.41.141'   #服务器的ip地址
# s=socket(AF_INET, SOCK_STREAM)
# import pandas as pd
# from math import floor
# import torch
# import torch.nn.functional as F
# import numpy as np
# import torchvision.transforms as transforms
# import torchvision.datasets as dset
# import socket as skt
# from utils import net2vec,vec2net,net_split,process,get_num_correct,get_interval,idx_container,get_all,shape_1d
# from model import NET
#
#
# leng  = 31043286
# image_size = (32,32)
# batch_size = 100
# transform=transforms.Compose([
#     transforms.RandomHorizontalFlip(),
#     transforms.Resize(image_size),
#     transforms.CenterCrop(image_size),
#     transforms.ToTensor(),
#     transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
# ])
# train_data=dset.CIFAR10(root='data/CIFAR10',train=True,transform=transform,download=True)
# test_data=dset.CIFAR10(root='data/CIFAR10',train=False,transform=transform,download=True)
# train_loader=torch.utils.data.DataLoader(train_data,batch_size=batch_size,shuffle=True)
# test_loader=torch.utils.data.DataLoader(test_data,batch_size=batch_size,shuffle=True)
# train_len=len(train_data)
# test_len=len(test_data)
# print(train_len,test_len)
# n_classes=10
#
#
# def train(model, device, q_flag,sr, epoch_num):
#     InitalModel_1d = net2vec(model)
#     optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
#     test_acc_list = []; train_acc_list = []
#     residual = torch.zeros(leng).to(device);q_res = np.zeros(leng)
#     if s_flag == 2 or 3: chunk_idx = idx_container(interval, shape_list,device)
#     else:           chunk_idx = []
#     for epoch in range(epoch_num):
#         total_loss = 0;train_correct = 0;test_correct = 0
#         if epoch == 0: TrainBefore_1d = InitalModel_1d
#         else:          TrainBefore_1d = NewModel_1d
#         for step, batch in enumerate(train_loader):
#             images, labels = batch
#             images, labels = images.to(device), labels.to(device)
#             outs = model.forward(images)
#             loss = F.cross_entropy(outs, labels)
#             optimizer.zero_grad()
#             loss.backward()
#             optimizer.step()
#             total_loss += loss.item()
#             train_correct += get_num_correct(outs, labels)
#         for step, batch in enumerate(test_loader):
#             images, labels = batch
#             images, labels = images.to(device), labels.to(device)
#             outs = model.forward(images)
#             test_correct += get_num_correct(outs, labels)
#         train_acc = train_correct / train_len; test_acc = test_correct / test_len
#         train_acc_list.append(train_acc); test_acc_list.append(test_acc)
#         print("第{}轮训练结果：loss:".format(epoch), round(total_loss,2), " train_correct:", round(train_acc,3), " test_correct:", round(test_acc,3))
#         DwR_1d = (TrainBefore_1d - net2vec(model)) + residual
#         if (s_flag>1) and int(sr)!=1:  splited_DwR = net_split(DwR_1d,shape_list)
#         else:                          splited_DwR=0
#         uploaded,q_res, TC, idx,layer_num, conv_idx_num = process(DwR_1d,leng, num_layer,q_res, q_flag, s_flag, sr,splited_DwR,chunk_idx)
#         print('数据处理完毕，开始发送。稀疏化{}s, 量化{}s, 编码{}s,打包{}s'.format(TC[0],TC[1],TC[2],TC[3]))
#         # all_idx = get_all(idx, layer_num, chunk_idx)
#         s.send(struct.pack('I', len(uploaded)))  #先告诉服务器发送消息的bit长度
#         if s_flag > 1 and int(sr)!=1:
#             s.send(uploaded)  # 全部数据
#             s.send(struct.pack('I', len(idx)))  # 告诉服务器消息中 idx 的长度
#             if s_flag == 3:  # SmartIdx
#                 s.send(struct.pack('%dI' % int(0.5 * len(shape_list) - 2), *layer_num))  # 告诉服务器每层有几个索引
#                 s.send(struct.pack('I', conv_idx_num))  # 告诉服务器前面多少个是卷积层索引
#                 idx = np.hstack((get_all(idx[:conv_idx_num], layer_num, chunk_idx).cpu().numpy(), idx[conv_idx_num:]))
#             else:
#                 s.send(struct.pack('%dI' % int(0.5 * len(shape_list)), *layer_num))  # 告诉服务器每层有几个索引
#                 idx = get_all(idx, layer_num, chunk_idx)
#         else:
#             s.send(uploaded)
#         residual[idx] = 0
#         recv = s.recv(4*leng, skt.MSG_WAITALL)
#         global_delta_1d = struct.unpack(('%df' % int(len(recv)/4)),recv)
#         NewModel_1d = TrainBefore_1d - torch.tensor(global_delta_1d).to(device)
#         updated_model = vec2net(NewModel_1d,shape_list)
#         for layer,param in enumerate(model.parameters()):
#             param.data = updated_model[layer].clone().detach().requires_grad_(True).type(torch.FloatTensor).to(device)
#
#         dir = '/home/wdl/include/fedpipe/data/'
#         data = []
#         data.append(test_acc_list); data.append(train_acc_list)
#         row = ['test', 'train']
#         save_file = pd.DataFrame(index=row, data=data)
#         save_file.to_csv(dir + '{}.csv'.format(filename), index=False, encoding="utf-8")
#     print('test acc{}'.format(test_acc_list))
#
# shape_list = [];num_layer=[]
# torch.manual_seed(1)
# net = NET(batch_size,n_classes)
# for param in net.parameters():
#     shape_list.append(param.data.shape)
#     num_layer.append(np.prod(np.array(param.data.shape)))
#
# interval = get_interval(num_layer)
#
# parser = argparse.ArgumentParser()
# parser.add_argument('--s', help='s_flag', type=int, default=0)
# parser.add_argument('--q', help='q_flag', type=int, default=1)
# parser.add_argument('--sr', help='sparse ratio', type=float, default=1e-1)
# parser.add_argument('--p', help='port', type=int, default=3333)
# parser.add_argument('--n', help='file name', type=str, default='')
# parser.add_argument('--e', help='epoch', type=int, default=30)
# args = vars(parser.parse_args())
#
# q_flag = args['q']; s_flag = args['s']; sr = args['sr'];port=args['p']; filename = args['n']; epoch = args['e']
# device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
# net.to(device)
# dim_size, shape_list_1d = shape_1d(shape_list)
#
# s.connect((address, port))
# print('connection has been built')
# s.send(struct.pack('I', leng) + struct.pack('I', len(shape_list))+ struct.pack('I', len(shape_list_1d)))
# s.send(struct.pack('%dI' % (len(dim_size)+len(shape_list_1d)+len(num_layer)),*dim_size+shape_list_1d+num_layer))   # meta3
#
# train(net,device,q_flag,sr,epoch)