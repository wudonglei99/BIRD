# -*- coding: UTF-8 -*-
# @Time : 2022/4/11 20:25
# @File : recv.py
# @Software: PyCharm
import numpy as np
import time
import struct
import socket as skt
from ulits import get_all
from math import floor
from itertools import chain
import lzma
import torch
from grace import deepreduce,helper
from ulits import *
class receive():
    def __init__(self,msg_len,sr,leng,s_flag,socket,shape_list,chunk_idx,num_layer):
        self.sr = sr
        self.leng = leng
        self.msg_len = msg_len
        self.s_flag = s_flag
        self.sock = socket
        self.shape_list = shape_list
        self.chunk_idx = chunk_idx
        s=time.clock();self.tmp = self.sock.recv(self.msg_len, skt.MSG_WAITALL);self.comm_cost = round(time.clock()-s,3)
        self.unpack_cost = []
        self.num_layer = num_layer

    def smart(self):
        idx_byte_len = struct.unpack('I', self.tmp[-4:])[0]
        idx_byte = lzma.decompress(self.tmp[-idx_byte_len-4:-4])
        value_len = int(self.msg_len - idx_byte_len-4-4-4)         # 3個4分別是mean,length,idx_len.
        s=time.clock()
        mean = struct.unpack('f',self.tmp[0:4])[0]
        length = struct.unpack('I',self.tmp[4:8])[0]
        from Tobytes import tonum
        sign = tonum("/home/wdl/project/fedpipe/tobytestool.so", length,self.tmp[8:value_len+8])
        value = sign*mean

        self.unpack_cost.append(time.clock()-s)

        s = time.clock()
        count,bb= tensor_layer_num(self.shape_list)
        len_conv_layer = struct.unpack('I', self.sock.recv(4, skt.MSG_WAITALL))[0]  # #  告诉服务器前面多少个是卷积层索引
        layer_num = struct.unpack('%dI' % int(len_conv_layer), self.sock.recv(int(4*len_conv_layer), skt.MSG_WAITALL))  # 每层有几个索引
        conv_idx_len = struct.unpack('I', self.sock.recv(4, skt.MSG_WAITALL))[0]  # #  告诉服务器前面多少个是卷积层索引
        conv_idx = np.array(struct.unpack('%dI' % conv_idx_len, idx_byte[:4 * conv_idx_len]))
        fc_idx = np.array(struct.unpack('%dI' % (0.25*len(idx_byte) - conv_idx_len), idx_byte[4 * conv_idx_len:]))
        self.unpack_cost.append(time.clock() - s)

        all_conv_idx = get_all(conv_idx, layer_num, self.chunk_idx,bb)
        idx = np.hstack((all_conv_idx.cpu().numpy(), fc_idx))

        print('索引数据量{}({}%)压缩率{}，值数据量{}({}%)压缩率{}'.
              format(idx_byte_len,round(idx_byte_len/self.msg_len,2),round(len(idx)*4/idx_byte_len,2)
                     ,value_len,round(value_len/self.msg_len,2), round(len(idx)*4/value_len,2)))

        return idx,value,[self.comm_cost,round(sum(self.unpack_cost),2)]

    def skdecode(self):
        import numpy as np
        import torch
        import pickle
        import time
        from skdecoder import SKDecoder
        s = time.clock()
        info = pickle.loads(self.tmp)
        info_pos =  info['pos']
        info_neg = info['neg']
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        if info_pos != {}:
            decoder = SKDecoder(info_pos['intervalid2prefix'], info_pos['hashtable_code_dict'], device)
            delta_key_interval_pos = decoder.parse(info_pos['prefix_code'], mode='prefix')
            decodekeys_pos = decoder.get_keys(info_pos['delta_keys_code'], info_pos['interval_size'], info_pos['keys_grads_len'])
            hashtable = decoder.parse(info_pos['hashtable_code'], mode='hashtable')
            bucketsid = decoder.minmaxsketch_query()
            decode_gradient_pos = decoder.get_gradient(info_pos['buckets_mean'].cpu().numpy())
        else:
            decodekeys_pos = torch.tensor([])
            decode_gradient_pos = torch.tensor([])

        if info_neg != {}:
            decoder = SKDecoder(info_neg['intervalid2prefix'], info_neg['hashtable_code_dict'], device)
            delta_key_interval_neg = decoder.parse(info_neg['prefix_code'], mode='prefix')
            decodekeys_neg = decoder.get_keys(info_neg['delta_keys_code'], info_neg['interval_size'], info_neg['keys_grads_len'])
            hashtable = decoder.parse(info_neg['hashtable_code'], mode='hashtable')
            bucketsid = decoder.minmaxsketch_query()
            decode_gradient_neg = decoder.get_gradient(info_neg['buckets_mean'].cpu().numpy())
        else:
            decodekeys_neg = torch.tensor([])
            decode_gradient_neg = torch.tensor([])
        result_keys = np.concatenate((decodekeys_pos, decodekeys_neg))
        result_grad = np.concatenate((decode_gradient_pos, decode_gradient_neg))
        self.unpack_cost.append(time.clock() - s)
        value_length = len(info_pos['buckets_mean'])+len(info_neg['buckets_mean'])+len(info_pos['hashtable_code'])+len(info_neg['hashtable_code'])
        print('索引数据量{}({})压缩率{}，值数据量{}({}%)压缩率{}'.
              format(result_keys.shape[0], round(result_keys.shape[0] / len(self.tmp),3),
                     round(result_keys.shape[0] * 4 / (len(info_pos['delta_keys_code'])+len(info_neg['delta_keys_code'])), 4)
                     , value_length, round(value_length / len(self.tmp), 3),
                     round(result_keys.shape[0] * 4 / value_length)))
        return result_keys, result_grad, [self.comm_cost,round(sum(self.unpack_cost),3)]


    def RB(self):
        idx_len = struct.unpack('I', self.sock.recv(4, skt.MSG_WAITALL))[0]  # 消息中idx的长度

        tmp = torch.zeros(self.leng,device="cuda:0")
        st_len = len(self.shape_list)
        value_len = int(self.msg_len - 4*idx_len-4*st_len-4)
        st_list = np.array(struct.unpack('%df' % st_len, self.tmp[:st_len * 4]))
        """每個sign 用 一個byte表示(棄用)"""
        # value_byte = self.tmp[4*st_len+4: 4*st_len+4+value_len]
        # tern_value = np.array(struct.unpack('%db' % value_len, value_byte))
        # tern_value = torch.tensor(tern_value, device="cuda:0", dtype=torch.float32)
        """每個sign 用 一個bite表示(==ywh==)"""
        length = struct.unpack('I', self.tmp[st_len * 4:st_len * 4+4])[0]
        from Tobytes import tonum
        sign = tonum("/home/wdl/project/fedpipe/tobytestool.so", length, self.tmp[4*st_len+4:4*st_len+4+value_len])
        sign = torch.tensor(sign, device="cuda:0", dtype=torch.float32)

        idx_byte = self.tmp[4*st_len+4+value_len:]
        s = time.clock()
        count,bb= tensor_layer_num(self.shape_list)
        layer_num = struct.unpack('%dI' % int(count), self.sock.recv(int(4*count), skt.MSG_WAITALL))
        idx = np.array(struct.unpack('%dI' % idx_len, idx_byte))
        self.unpack_cost.append(time.clock() - s)
        idx = get_all(idx, layer_num, self.chunk_idx,bb)
        tmp[idx] = sign
        split_tmp = torch.split(tmp,self.num_layer)
        recovered_model = []
        for i in range(len(st_list)):
            recovered_model.append(split_tmp[i]*st_list[i])
        out = torch.cat((recovered_model[0], recovered_model[1]))
        for j in range(2, len(recovered_model)):
            out = torch.cat((out, recovered_model[j]))
        value = out.cpu().numpy()
        print('索引数据量{}({})压缩率{}，值数据量{}({}%)压缩率{}'.
          format(len(idx_byte),round(len(idx_byte)/self.msg_len,2),round(len(idx)*4/len(idx_byte),2)
                 ,value_len,round(value_len/self.msg_len,2), round(len(idx)*4/value_len),2))
        return idx,value, [self.comm_cost, round(sum(self.unpack_cost), 2)]

    # def RB(self):
    #     idx_len = struct.unpack('I', self.sock.recv(4, skt.MSG_WAITALL))[0]  # 消息中idx的长度
    #     '''block sq'''
    #     tmp = torch.zeros(self.leng,device="cuda:0")
    #     st_len = len(self.shape_list)
    #     value_len = int(self.msg_len - 4*idx_len-4*st_len)
    #
    #     st_list = np.array(struct.unpack('%df' % st_len, self.tmp[:st_len * 4]))
    #     tern_value = np.array(struct.unpack('%db' % value_len, self.tmp[4*st_len: 4*st_len+value_len]))
    #     tern_value = torch.tensor(tern_value,device="cuda:0",dtype=torch.float32)
    #
    #     idx_byte = self.tmp[4*st_len+value_len:]
    #     s = time.clock()
    #     layer_num = struct.unpack('%dI' % int(0.5 * len(self.shape_list)), self.sock.recv(int(4 * 0.5 * len(self.shape_list)), skt.MSG_WAITALL))
    #     idx = np.array(struct.unpack('%dI' % idx_len, idx_byte))
    #     self.unpack_cost.append(time.clock() - s)
    #     idx = get_all(idx, layer_num, self.chunk_idx)
    #     tmp[idx] = tern_value
    #     split_tmp = torch.split(tmp,self.num_layer)
    #     recovered_model = []
    #     for i in range(len(st_list)):
    #         recovered_model.append(split_tmp[i]*st_list[i])
    #     out = torch.cat((recovered_model[0], recovered_model[1]))
    #     for j in range(2, len(recovered_model)):
    #         out = torch.cat((out, recovered_model[j]))
    #     value = out.cpu().numpy()
    #     return idx,value, [self.comm_cost, round(sum(self.unpack_cost), 3)]


    def DeepReduce(self):
        idx_len = struct.unpack('%dI' % 2, self.sock.recv(8, skt.MSG_WAITALL)) # 消息中idx的长度
        mapping_byte = self.tmp[-idx_len[1]:]
        mapping = torch.tensor(struct.unpack('%dB' % idx_len[1], mapping_byte),device='cuda:0').type(torch.uint8)
        idx_byte = self.tmp[-(idx_len[0]+idx_len[1]):-idx_len[1]]
        idx = torch.tensor(struct.unpack('%dB' % idx_len[0], idx_byte ),device='cuda:0').type(torch.uint8)
        value_byte = self.tmp[:self.msg_len-(idx_len[0]+idx_len[1])]
        value = torch.tensor(struct.unpack('%df' % int(0.25*len(value_byte)), value_byte),device='cuda:0').type(torch.double)

        params = {'compressor': 'topk', 'compress_ratio': 0.01, 'deepreduce': 'both', 'value': 'polyfit',
                  'index': 'bloom', 'policy': 'leftmost'}
        grc = deepreduce.deepreduce_from_params(params)

        value, index = grc.compressor.decompress((value, idx, mapping), self.leng)  # 解壓縮

        print('索引数据量{}({})压缩率{}，值数据量{}({})压缩率{}'.
              format(len(idx_byte),
                     round(len(idx_byte) / self.msg_len, 3),
                     round(len(index) * 4 / len(idx_byte), 3),
                     len(value_byte)+len(mapping_byte),
                      round((len(value_byte)+len(mapping_byte)) / self.msg_len, 3),
                     round(len(index) * 4 / (len(value_byte)+len(mapping_byte)), 3)))

        return index,value.cpu().numpy(), [self.comm_cost,0]


    def sbc(self):
        idx_byte_len = struct.unpack('I', self.tmp[-4:])[0]
        s = time.clock()
        idx_byte = lzma.decompress(self.tmp[-idx_byte_len-4:-4])
        value_len = int(self.msg_len - idx_byte_len - 4 - 4 - 4)
        idx = np.array(struct.unpack('%dI' % int(0.25*len(idx_byte)), idx_byte))
        value_byte = self.tmp[4+4:len(idx) + 4+4]
        mean = struct.unpack('f', self.tmp[0:4])[0]
        length = struct.unpack('I', self.tmp[4:8])[0]
        from Tobytes import tonum
        sign = tonum("/home/wdl/project/fedpipe/tobytestool.so", length, self.tmp[8:value_len + 8])
        value = sign * mean
        self.unpack_cost.append(time.clock() - s)
        print('索引数据量{}({})压缩率{}，值数据量{}({}%)压缩率{}'.
         format(idx_byte_len,round(idx_byte_len/self.msg_len,2),round(len(idx)*4/idx_byte_len,2),
                len(value_byte),round(len(value_byte)/self.msg_len,2), round(len(idx)*4/value_len,2)))
        return idx, value,[self.comm_cost,round(sum(self.unpack_cost),2)]


    def std(self):
        s = time.clock()
        recvdata = struct.unpack(('%df' % self.leng), self.tmp)
        self.unpack_cost.append(time.clock() - s)
        return recvdata, [self.comm_cost, round(sum(self.unpack_cost), 3)]

    def randk(self):
        value_len = floor(self.sr * self.leng)
        value = struct.unpack(('%df' % value_len), self.tmp[:4*value_len])
        idx = np.array(struct.unpack('%dI' % value_len, self.tmp[4*value_len:]))
        return idx,value,[self.comm_cost,0]

    def topk(self):
        value_len = floor(self.sr * self.leng)
        s = time.clock()
        '''稀疏化+量化'''
        value = struct.unpack('f',self.tmp[0:4])[0]*np.array(struct.unpack(('%db' % value_len), self.tmp[4:value_len+4]))
        idx = np.array(struct.unpack(('%dI' % value_len), self.tmp[value_len + 4:]))
        '''仅稀疏化(华为测试)'''
        # value = np.array(struct.unpack(('%df' % value_len), self.tmp[:4*value_len]))
        # idx = np.array(struct.unpack(('%dI' % value_len), self.tmp[4*value_len:]))

        self.unpack_cost.append(time.clock() - s)
        return idx, value,[self.comm_cost,round(sum(self.unpack_cost),3)]

        # if self.q_flag == 0: recvdata = struct.unpack(('%df' % self.leng), self.tmp)
        # elif self.q_flag==1: recvdata = np.array(struct.unpack(('%db' % self.leng), self.tmp[4:])) * struct.unpack('f', self.tmp[0:4])[0]
        # else:
        #     s_list = struct.unpack(('%df' %  layer), self.tmp[:4 * layer])
        #     z_list = struct.unpack(('%df' %  layer), self.tmp[4 * layer: 8 * layer])
        #     int_param = struct.unpack('%dB' % self.leng, self.tmp[8 * layer:])
        #     k = 0; recvdata = []
        #     for i, num in enumerate(num_layer):
        #         int_layer = np.asarray(int_param[k:k + num])
        #         restore_layer = s_list[i] * (int_layer - z_list[i])
        #         recvdata.append(restore_layer)
        #         k += num
        #     recvdata = np.array(list(chain.from_iterable(recvdata)))
        # self.unpack_cost.append(time.clock() - s)
        # return recvdata,[self.comm_cost,round(sum(self.unpack_cost),3)]