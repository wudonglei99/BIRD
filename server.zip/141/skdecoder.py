import numpy as np
import torch
import struct

class SKDecoder(): 
  def __init__(self, intervalid2prefix, hashtable_code_dict, device):
    self.prefix2intervalid = {bytes(v, encoding='utf-8'):k for k, v in intervalid2prefix.items()}
    self.hashtable_code_dict = {bytes(v, encoding='utf-8'):k for k, v in hashtable_code_dict.items()}
    self.device = device
    self.sketch_s = 2
    self.sketch_m = 3000
    # self.hashset = {
    #   0:lambda key:(key % 247)**2 % self.sketch_m,
    #   1:lambda key:(key % 161)**3 % self.sketch_m,
    # }
    self.hashset = {
      0:lambda key:((((key**3 % 247) + (13*key%271))%517)*(key+111)%191)**2 % self.sketch_m,
      1:lambda key:(((key**2 % 161) + (19*key%171))*(key % 3751 +31*key)%141)**3 % self.sketch_m,
    }

    self.prefix_intervalid = None
    self.hashtable = None
    self.delta_keys = None
    self.keys = None
    self.bucketsid = None
    self.gradient = None
    self.kv_pairs = None

  def parse(self, code, mode='prefix'):
    if mode == 'prefix':
      dictionary = self.prefix2intervalid
    elif mode == 'hashtable':
      dictionary = self.hashtable_code_dict
    else:
      raise ValueError("mode should be 'prefix' or 'hashtable'")
    start = 0
    end = 1
    parse_result = []
    while start < len(code) and end <= len(code):
      substr = code[start:end]
      if substr in dictionary:
        parse_result.append(dictionary[substr])
        start = end
        end += 1
      else:
        end += 1
    if start != end-1:
      raise ValueError("code error!")
    parse_result = np.asarray(parse_result, dtype=np.int32)
    if mode == 'hashtable':
      parse_result = parse_result.reshape((self.sketch_s, self.sketch_m))
      self.hashtable = parse_result
    else:
      self.prefix_intervalid = parse_result
    return parse_result

  def get_keys(self, delta_keys_code, interval_size, length):
    self.delta_keys = struct.unpack('%di'%length, delta_keys_code)
    keys = np.cumsum(self.delta_keys)
    self.keys = keys
    return keys

  def minmaxsketch_query(self):
    value_table = np.zeros(self.keys.shape[0]*self.sketch_s, dtype=np.int32).reshape(self.sketch_s, -1)
    for row in range(self.sketch_s):
      cols = self.hashset[row](self.keys)
      if row == 1:
        self.temp = cols
      value_table[row, :] = self.hashtable[row][cols]
    bucketsid = np.max(value_table, axis=0)
    bucketsid = bucketsid.astype(np.int32)
    self.bucketsid = bucketsid
    return bucketsid

  def get_gradient(self, buckets_mean):
    self.gradient = buckets_mean[self.bucketsid]
    return self.gradient

  def get_kv_pairs(self):
    kv_pairs = []
    for key, grad in zip(self.keys, self.gradient):
      kv_pairs.append([key, grad])
    kv_pairs = torch.tensor(kv_pairs).to(self.device)
    self.kv_pairs = kv_pairs
    return kv_pairs
