from socket import *
import socket as skt
from math import floor
import threading
import numpy as np
import lzma
import struct
import time
from parser import arg_parser
from recv import receive
from itertools import chain
from ulits import get_shape,idx_container,get_interval
class MyThread(threading.Thread):
    def __init__(self, signal,clientsock,clientaddress,e):
        threading.Thread.__init__(self)
        self.signal = signal
        self.sock = clientsock
        self.addr = clientaddress
        self.epoch = e

    def run(self):
        msg_len = struct.unpack('I', self.sock.recv(4, skt.MSG_WAITALL))[0]  #总byte长度
        RECV = receive(msg_len,sr,leng,s_flag,self.sock,shape_list,chunk_idx,num_layer)
        if int(sr) != 1:  # 稀疏
            if  s_flag==3:  # smt
                recvdata = np.zeros(leng)
                idx, value, time_cost = RECV.smart()
                recvdata[idx] = value
            elif s_flag==2:
                idx,value, time_cost = RECV.RB()
                recvdata = value
            elif s_flag==4:
                recvdata = np.zeros(leng)
                idx, value, time_cost = RECV.sbc()
                recvdata[idx] = value
            elif s_flag == 5:
                idx,value,time_cost  = RECV.DeepReduce()
                recvdata = value
            elif s_flag==6:
                recvdata = np.zeros(leng)
                idx, value, time_cost = RECV.skdecode()
                recvdata[idx] = value
            elif s_flag==1:
                recvdata = np.zeros(leng)
                idx, value, time_cost = RECV.randk()
                recvdata[idx] = value
            else:
                recvdata = np.zeros(leng)
                idx, value, time_cost = RECV.topk()
                recvdata[idx] = value
        else:        # 无稀疏
            value, time_cost = RECV.std()
            recvdata = value;       idx = list(range(leng))

        print('通信{}s,解包{}s,总数据量{} bytes, 总压缩率{},稀疏率{}'.format(
        time_cost[0],time_cost[1], msg_len, round(4 * leng /msg_len, 3), round(len(idx) / leng, 3)))

        client_count.append(self.addr)
        client_data.append(recvdata)  # append但是没append完，len也等于2
        '******************'
        self.signal.wait()
        '******************'
        assert client_data!=[]
        AvgParam = np.mean((client_data),0)  # 联邦平均FedAvg
        # AvgParam = np.clip(AvgParam, a_max=0.035, a_min=-0.035) # clip
        self.sock.send(struct.pack(('%df' % leng), *AvgParam))
        client_count.remove(self.addr)

if __name__ == "__main__":

    s_flag,sr,port,epoch,device,sparse = arg_parser()
    s = socket(AF_INET, SOCK_STREAM)
    s.bind(('0.0.0.0',port))
    print('listening...')
    s.listen(10)     #最大连接数
    client_data = []; client_count = [];client_list = []; overlap = []; overlap_list = [];time_cost=[]
    client_num = 2
    for c in range(client_num):
        clientsock, clientaddress = s.accept()
        client_list.append([clientsock, clientaddress])
        meta1 = struct.unpack('%dI' % 3, clientsock.recv(12))
        meta3 = struct.unpack('%dI' % (meta1[1]+meta1[2]+meta1[1]), clientsock.recv((meta1[1]+meta1[2]+meta1[1])*4))
        print('与第{}个客户端{}建立连接'.format(c, clientaddress[0].split(".")[-1]))
    leng, layer, dim_len = meta1[0], meta1[1], meta1[2]; print('{}层，{}个参数'.format(layer,leng))
    dim_size,shape_1d, num_layer = meta3[:layer], meta3[layer:layer+dim_len], meta3[layer+dim_len:]
    interval = get_interval(num_layer)
    shape_list = get_shape(shape_1d,dim_size)
    chunk_idx = idx_container(interval, shape_list, device)
    start = time.time()
    for e in range(epoch):
        s_epoch = time.time()
        print('*'*68);print(' '*11,'Round {} | port {} | {}| hyper{}'.format(e,port,sparse,sr),' '*8);print('*'*68)
        signal = threading.Event()
        for c in range(client_num):
            clientsock = client_list[c][0]
            clientaddress = client_list[c][1]
            thread = MyThread(signal,clientsock,clientaddress,e)
            thread.start()  # 只有收到第当前客户端数据后才会执行下一次的for循环
        while True:   #保证当前客户端发来的数据加到了data list里才开始下一个客户端
             if len(client_data)==len(client_list):
                signal.set()
                break
        while True:
            if  client_count==[]:   # 保证数据发出去以后再清空 data list
                client_data=[]
                overlap = []
                break
        print('本轮耗时：{}秒'.format(round(time.time() - s_epoch, 2)))
        time_cost.append(round(time.time() - s_epoch, 2))
    print('总耗时：{}秒'.format(round(time.time()-start,2)))











# s_decode = time.time();idx_byte = lzma.decompress(tmp[floor(sr * leng) * 4:]); decode_cost = round(time.time()-s_decode,2)
# print("收到来自{}的模型，稀疏率为{}，共{}个".format(self.addr[0].split(".")[-1],sr,len(client_data)))
# print( "SOCKET：sent back to{}".format(self.addr))