import numpy as np
import torch
import numpy as np
tmp = torch.zeros(10)
idx = torch.tensor([2,4,6])
p1= torch.tensor([1,2,3],dtype=torch.int8)
tmp[idx] = p1
s = torch.tensor(-1)
p = s*p1
p0=1-p1
x = np.transpose(np.vstack((p0,p1)))
a = torch.randn(1,3)
b = torch.randn(1,3)
prob = torch.cat((a,b),dim=0)
x = torch.t(prob)

print(list(range(56,70)))
from torch.utils.data.sampler import WeightedRandomSampler
s  = list(WeightedRandomSampler(np.array([[0.5,0.5],[0.5,0.5],[0.5,0.5],[0.5,0.5],[0.5,0.5],[0.5,0.5]]), 1, replacement=True))

b = a.flatten(start_dim=1,end_dim=3)
idx_byte=0
if idx_byte:
    print(0)
else:
    print(1)
a[b] = 0
import argparse   #步骤一
from golomb_coding import golomb_coding
a1 = golomb_coding(0, 3) # 10
a2 = golomb_coding(1, 3) # 110
a3 = golomb_coding(2, 3) # 111dffff
golomb_coding(3, 3) # 010
golomb_coding(4, 3) # 0110
golomb_coding(5, 3) # 0111
golomb_coding(6, 3) # 0010
golomb_coding(7, 3) # 00110
golomb_coding(8, 3) # 00111
golomb_coding(9, 3) # 00010
golomb_coding(10, 3) # 000110
golomb_coding(11, 3) # 000111
golomb_coding(12, 3) # 000010
golomb_coding(13, 3) # 0000110
golomb_coding(14, 3) # 0000111
golomb_coding(15, 3) # 0000010