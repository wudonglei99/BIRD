from Tobytes import *
import torch
import struct
# path: the path where the tobytestool.so exists
# tensor: the tensor for processing 
# return: signigicant bit length,  0b'xff\xff......'

tensor = torch.tensor([1 if i%2==0 else -1 for i in range(30000000)])
path = "/home/ywh/code/client/tobytestool.so"
length, resbytes = tobytes(path, tensor)
# length 需要struct.pack进行打包，resbytes不需要，可直接用socket发送
pack_bytes = struct.pack("I", length)
length = struct.unpack("I", pack_bytes)[0]
result_array = tonum(path, length, resbytes)
# result_array = torch.from_numpy(result_array)
# print(torch.unique(result_array==tensor, return_counts=True))
