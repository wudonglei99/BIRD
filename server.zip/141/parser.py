# -*- coding: UTF-8 -*-
# @Time : 2022/4/11 21:15
# @File : parser.py
# @Software: PyCharm
import argparse
import torch

def arg_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument('--s', help='s_flag', type=int, default=4)
    parser.add_argument('--sr', help='sparse ratio', type=float, default=0.1) #1e-1
    parser.add_argument('--p', help='port', type=int, default=3333)
    parser.add_argument('--e', help='epoch', type=int, default=30)
    args = vars(parser.parse_args())

    s_flag = args['s']; sr = args['sr'];port = args['p']; epoch = args['e']
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if   s_flag == 0: sparse = 'Top-K'
    elif s_flag == 1: sparse = 'Rand-K'
    elif s_flag == 2: sparse = 'Bird'
    elif s_flag == 3: sparse = 'SmartIdx'
    elif s_flag == 4: sparse = 'SBC'
    elif s_flag == 5: sparse = 'DeepReduce'
    elif s_flag == 6: sparse = 'skc'
    else: sparse = 'None'
    return s_flag,sr,port,epoch,device,sparse

