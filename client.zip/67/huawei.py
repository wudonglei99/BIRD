

import time
from socket import *
import struct
import argparse
address='10.249.41.141'   #服务器的ip地址
s=socket(AF_INET, SOCK_STREAM)
import pandas as pd
from math import floor
import torch
import torch.nn.functional as F
import numpy as np
import torchvision.transforms as transforms
import torchvision.datasets as dset
import socket as skt
from huawei_utils import recover,net2vec,vec2net,net_split,process,get_num_correct,get_interval,idx_container,comm,shape_1d
from model import NET


leng  = 31043286
image_size = (32,32)
batch_size = 100
transform=transforms.Compose([
    transforms.RandomHorizontalFlip(),
    transforms.Resize(image_size),
    transforms.CenterCrop(image_size),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
])
train_data=dset.CIFAR10(root='data/CIFAR10',train=True,transform=transform,download=True)
test_data=dset.CIFAR10(root='data/CIFAR10',train=False,transform=transform,download=True)
train_loader=torch.utils.data.DataLoader(train_data,batch_size=batch_size,shuffle=True)
test_loader=torch.utils.data.DataLoader(test_data,batch_size=batch_size,shuffle=True)
train_len=len(train_data)
test_len=len(test_data)
print(train_len,test_len)
n_classes=10


def train(model, device,sr, epoch_num):
    InitalModel_1d = net2vec(model)
    optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
    test_acc_list = []; train_acc_list = []
    residual = torch.zeros(leng).to(device); res_q = torch.zeros(leng).to(device)
    if s_flag == 2 or 3: chunk_idx = idx_container(interval, shape_list,device)
    else:           chunk_idx = []
    for epoch in range(epoch_num):
        s_epoch = time.time()
        total_loss = 0;train_correct = 0;test_correct = 0
        if epoch == 0: TrainBefore_1d = InitalModel_1d
        else:          TrainBefore_1d = NewModel_1d
        for step, batch in enumerate(train_loader):
            s_training = time.time()
            images, labels = batch
            images, labels = images.to(device), labels.to(device)
            outs = model.forward(images)
            loss = F.cross_entropy(outs, labels)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
            train_correct += get_num_correct(outs, labels)
            training_time=round(time.time()-s_training,4)

            DwR_1d = (TrainBefore_1d - net2vec(model)) + residual
            if (s_flag>1) and int(sr)!=1:  splited_DwR = net_split(DwR_1d,shape_list)
            else:                          splited_DwR = 0
            uploaded, cost, idx, meta, res_q = process(DwR_1d,leng, s_flag, sr,splited_DwR,chunk_idx,res_q)
            print('Round{},Step{},数据处理完毕，开始发送。压缩耗时{}s,打包耗时{}s,训练耗时{}s'
                  .format(epoch,step,cost[0],cost[1],training_time))

            recover_time = recover(uploaded,sr,leng);print('反量化耗时',recover_time)
            print((leng*4-len(uploaded))/(cost[0]+recover_time))
            residual = comm(s,sr,s_flag,uploaded,idx,meta,DwR_1d,residual,shape_list,chunk_idx)
            tmp = s.recv(4, skt.MSG_WAITALL)
            s_recv = time.time()
            recv = s.recv(4*leng, skt.MSG_WAITALL)
            print('客户端接收全局模型耗时',round(time.time()-s_recv,4))

            s_unpack = time.time()
            global_delta_1d = struct.unpack(('%df' % int(len(recv)/4)),recv)
            print('客户端解包时间',round(time.time()-s_unpack,4))

            s_update = time.time()
            NewModel_1d = TrainBefore_1d - torch.tensor(global_delta_1d).to(device)
            updated_model = vec2net(NewModel_1d,shape_list)
            for layer,param in enumerate(model.parameters()):
                param.data = updated_model[layer].clone().detach().requires_grad_(True).type(torch.FloatTensor).to(device)
            print('客户端模型更新时间',round(time.time()-s_update,4))
            print('本轮耗时：{}秒'.format(round(time.time() - s_training, 2)))

        for step, batch in enumerate(test_loader):
            images, labels = batch
            images, labels = images.to(device), labels.to(device)
            outs = model.forward(images)
            test_correct += get_num_correct(outs, labels)
        train_acc = train_correct / train_len; test_acc = test_correct / test_len
        train_acc_list.append(train_acc); test_acc_list.append(test_acc)
        print("第{}轮训练结果：loss:".format(epoch), round(total_loss,2), " train_correct:", round(train_acc,3), " test_correct:", round(test_acc,3))
    print('test acc{}'.format(test_acc_list))

shape_list = [];num_layer=[]
torch.manual_seed(1)
net = NET(batch_size,n_classes)
for param in net.parameters():
    shape_list.append(param.data.shape)
    num_layer.append(np.prod(np.array(param.data.shape)))

interval = get_interval(num_layer)

parser = argparse.ArgumentParser()
parser.add_argument('--s', help='s_flag', type=int, default=0)
parser.add_argument('--sr', help='sparse ratio', type=float, default=1e-1)
parser.add_argument('--p', help='port', type=int, default=33333)
parser.add_argument('--n', help='file name', type=str, default='')
parser.add_argument('--e', help='epoch', type=int, default=300)
args = vars(parser.parse_args())
s_flag = args['s']; sr = args['sr'];port=args['p']; filename = args['n']; epoch = args['e']
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
net.to(device)
dim_size, shape_list_1d = shape_1d(shape_list)

s.connect((address, port))
print('connection has been built')
s.send(struct.pack('I', leng) + struct.pack('I', len(shape_list))+ struct.pack('I', len(shape_list_1d)))
s.send(struct.pack('%dI' % (len(dim_size)+len(shape_list_1d)+len(num_layer)),*dim_size+shape_list_1d+num_layer))   # meta3

train(net,device,sr,epoch)