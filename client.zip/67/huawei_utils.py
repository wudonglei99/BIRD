import time
from socket import *
import struct
from quan import sq,block_sq,qd
address='10.249.41.141'   #服务器的ip地址
s=socket(AF_INET, SOCK_STREAM)
from math import floor,ceil
import torch
import numpy as np
from itertools import chain
import random
from torch.utils.data.sampler import WeightedRandomSampler


def get_num_correct(out, labels):  #求准确率
    return out.argmax(dim=1).eq(labels).sum().item()

def shape_1d(shape_list):
    shape_1d = []; dim_size = []
    for dim in shape_list:
        dim_size.append(len(dim))
        for item in dim:
            shape_1d.append(item)
    return dim_size, shape_1d



def get_interval(flatten_list):
    sum = 0; interval = []
    for l in flatten_list:
        sum += l
        interval.append(sum)
    return interval

def vec2net(vec, shape_list):
    k = 0
    net = []
    for item in shape_list:
        temp = 1
        for _ in range(len(item)):
            temp *= item[_]
        param_1D = vec[k:k + temp]
        param = torch.reshape(param_1D, item)
        net.append(param)
        k += temp
    return net

def net2vec(model):
    model_1d = []
    for layer in model.parameters():
        layer_1d = torch.flatten(layer.data)
        model_1d.append(layer_1d)
    out = torch.cat((model_1d[0],model_1d[1]),0)
    for j in range(2,len(model_1d)):
        out = torch.cat((out, model_1d[j]), dim=0)
    return out

def idx_container(interval,shape_list,device):
    layer_idx = []; start = 0; chunk_idx = []
    for i in range(len(interval)):
        layer_idx.append(torch.tensor(list(range(start,interval[i])),device=device))
        start = interval[i]
    for j, layer in enumerate(layer_idx):
        layer_with_chunk = []
        if len(shape_list[j])!=1:
            chunk_len = np.prod(np.array(shape_list[j])[1:])
            for k in range(shape_list[j][0]):
                layer_with_chunk.append(layer[k*chunk_len:(k+1)*chunk_len])
        else:
            layer_with_chunk.append(layer)
        chunk_idx.append(layer_with_chunk)
    return chunk_idx

def get_all(idx,layer_num,chunk_idx):
    start = 0; tmp = []; i=0
    for num in layer_num:
        w = list(np.array(chunk_idx[i * 2])[idx[start:start + num]])
        w.append(chunk_idx[i*2+1][0][idx[start:start+num]])
        tmp.append(w)
        start=start+num;       i+=1
    tmp = (list(chain.from_iterable(tmp)))
    all_idx = torch.cat((tmp[0],tmp[1]), dim=0)
    for item in tmp[2:]:
        all_idx = torch.cat((all_idx,item), dim=0)
    return all_idx

def net_split(DwR_1d,shape_list):
    DwR = vec2net(DwR_1d, shape_list)
    conv = []; fc = []; bias = []
    for layer in DwR:
        if len(layer.data.shape)==4:   conv.append(torch.flatten(layer.data,start_dim=1))
        elif len(layer.data.shape)==2: fc.append(layer.data)
        else:                          bias.append(layer.data)
    return [conv, fc,bias]

def statistical(idx,interval):
    layer_in = np.zeros(len(interval))
    for i in idx:
        for j in range(len(interval)):
            if interval[j]< i <interval[j+1] or 0 < i <interval[j]:
                layer_in[j]+=int(1)
                break
    return layer_in

def smartidx(DwR_1d,splited_DwR, sr,leng, chunk_idx):
    var_abs = torch.abs(DwR_1d); n = 0
    _, topk_1d = torch.topk(var_abs, floor(sr * leng))
    topk_1d = set(topk_1d.cpu().numpy().tolist())
    conv_chunk = chunk_idx[:2*len(splited_DwR[0])]

    for layer in range(len(splited_DwR[0])):
        n+=torch.prod(torch.tensor(splited_DwR[0][layer].shape))
    conv_idx_list = set(list(range(n)))
    conv_param=conv_idx_list.intersection(topk_1d)
    fc_idx = torch.tensor(list(topk_1d-conv_param),device="cuda:0")

    layer_block_num = []; conv_idx = []
    for layer in conv_chunk:
        id_list=[]
        if len(layer)!=1:
            for id, filter in enumerate(layer):
                filter = set(filter.cpu().numpy())
                if len(filter.intersection(conv_param))!=0:
                    id_list.append(id)
            conv_idx.append(id_list);layer_block_num.append(len(id_list))
    conv_idx = list(chain.from_iterable(conv_idx))

    all_conv_idx = get_all(conv_idx, layer_block_num, chunk_idx)
    all_idx = torch.cat((all_conv_idx,fc_idx),0)
    value = DwR_1d[all_idx]
    quaned_value = [torch.mean(torch.abs(value)), torch.sign(value).type(torch.int8)]
    uploaded_idx = torch.cat((torch.tensor(conv_idx,device="cuda:0"),fc_idx),0)
    return uploaded_idx, quaned_value, [layer_block_num, len(conv_idx)]


def RB(splited_DwR,sr):
    st_list_q=[]; st_list_s=[]; selected_block=[];selected_bias=[]; block_idx = []; layer_block_num=[];st_list=[]
    for i,block_layer in enumerate(splited_DwR[0]+splited_DwR[1]):
        '''第一次随机量化'''
        norm_list = torch.norm(torch.abs(block_layer), dim=1,p=2)
        s_t =  torch.max(norm_list);      st_list_q.append(s_t/np.sqrt( block_layer.shape[1]))
        prob_1 =  norm_list / s_t
        prob_0 = 1 - prob_1
        prob = torch.t(torch.vstack((prob_0, prob_1)))
        bi = list(WeightedRandomSampler(prob, 1))
        bi = torch.tensor(np.reshape(bi, [len(bi), ]),device="cuda:0")
        big_norm_idx = torch.where(bi>0)[0]
        '''第二次随机稀疏化'''
        if len(big_norm_idx) > ceil(sr * len(block_layer)):
            IdxOfIdx = torch.randperm(len(big_norm_idx),device="cuda:0")[:ceil(sr * len(block_layer))]
            idx = big_norm_idx[IdxOfIdx]
        else:
            idx = big_norm_idx
        st_list_s.append(1/(len(idx)/len(big_norm_idx)))
        if len(idx) == 0:
            layer_block_num.append(0)
        else:
            idx, _ = torch.sort(idx)
            selected_block.append(block_layer[idx])
            selected_bias.append(splited_DwR[2][i][idx])
            block_idx.append(idx); layer_block_num.append(len(idx))#; layer_num.append(len(idx))
    '''获取实际上传索引'''
    idx_1d = torch.cat((block_idx[0], block_idx[1]), 0)
    for j in range(2, len(block_idx)):
        idx_1d = torch.cat((idx_1d, block_idx[j]), dim=0)
    '''获取实际上传参数值'''
    selected_param = list(chain.from_iterable(zip(selected_block, selected_bias)))
    selected_param_sign=[]
    for item in selected_param:
        selected_param_sign.append(torch.sign(item))
    st_list = st_list_s*np.array(st_list_q)
    st_list = list(chain.from_iterable(zip(st_list, st_list)))

    value_1d = torch.cat((torch.flatten(selected_param_sign[0]), torch.flatten(selected_param_sign[1])), 0)
    for j in range(2, len(selected_param_sign)):
        value_1d = torch.cat((value_1d, torch.flatten(selected_param_sign[j])), dim=0)

    value_1d = value_1d.type(torch.int8)
    st_list = torch.tensor(st_list, device="cuda:0")
    return idx_1d,[st_list,value_1d],layer_block_num


# def recover(compressed_data, sr, leng):
#     value_len = floor(sr * leng)
#     recvdata = np.zeros(leng)
#     value = struct.unpack('f',compressed_data[0:4])[0]*np.array(struct.unpack(('%db' % value_len), compressed_data[4: value_len+4]))
#     idx = np.array(struct.unpack(('%dI' % value_len), compressed_data[value_len + 4:]))
#     recvdata[idx] = value
#     return recvdata

def recover(compressed_data, sr, leng):
    value_len = floor(sr * leng)
    recvdata = np.zeros(leng)
    '''稀疏化+量化'''
    # mag = struct.unpack('f',compressed_data[0:4])[0]
    # sign = np.array(struct.unpack(('%db' % value_len), compressed_data[4: value_len+4]))
    # idx = np.array(struct.unpack(('%dI' % value_len), compressed_data[value_len + 4:]))
    # s = time.clock(); recvdata[idx] = mag*sign; cost = time.clock()-s
    '''仅稀疏化 '''
    value = np.array(struct.unpack(('%df' % value_len), compressed_data[:4*value_len]))
    idx = np.array(struct.unpack(('%dI' % value_len), compressed_data[4*value_len:]))
    cost=0
    return cost

def compression(DwR_1d,leng,sr,A_flag,splited_DwR,chunk_idx,res_q):
    meta = []; Nres_q=0   # layer_num,  conv_idx_num
    if A_flag == 0:    # sbc
        '''topk'''
        s_sparse = time.clock()
        var_abs = torch.abs(DwR_1d)
        _,idx = torch.topk(var_abs, floor(sr*leng))
        print('稀疏化耗时',time.clock() - s_sparse)
        s_mq = time.clock()
        value = DwR_1d[idx]
        '''mq '''
        # value = [torch.mean(torch.abs(value)), torch.sign(value).type(torch.int8)]
        # print('量化耗时',time.clock()-s_mq)
    elif A_flag==1:     # rand k
        idx = torch.randint(high = leng, size = (floor(sr*leng),),device ="cuda:0")  # 快  重复(重复率低)
        # s = time.clock(); torch.randint(high = leng, size = (floor(sr*leng),));print('xxx',time.clock()-s)
        # s = time.clock();idx = torch.randperm(leng, device="cpu")[:ceil(sr * leng)];print('xxx',time.clock()-s)
        # s = time.clock();idx = torch.tensor(random.sample(list(range(leng)), floor(sr * leng)));print('xxx',time.clock()-s)
        value = DwR_1d[idx]*(1/(sr*2))
        value = sq(value)
    elif A_flag==2:     # RB
        idx, value, meta = RB(splited_DwR,sr)
    else:               # SmartIdx
        idx, value, meta = smartidx(DwR_1d,splited_DwR, sr,leng,chunk_idx)
    return idx,value,meta,Nres_q


def packing(idx,value, A_flag):
    idx_byte = struct.pack(('%dI' % len(idx)), *idx)
    if A_flag == 0 or 1:    # sbc/randk/dgc
        '''稀疏化+量化'''
        # value[0], value[1] = value[0].cpu().numpy(), value[1].cpu().numpy()
        # value_byte = struct.pack('f', value[0]) + struct.pack(('%db' % len(value[1])), *value[1])
        '''仅稀疏化'''
        value = value.cpu().numpy()
        value_byte = struct.pack(('%df' % len(value)), *value)
    elif A_flag==2:
        st_list = value[0];     Tern_value = value[1]
        Tern_value = Tern_value.cpu().numpy();  st_list = st_list.cpu().numpy()
        value_byte = struct.pack('%df' % len(st_list), *st_list) + struct.pack(('%db' % len(Tern_value)), *Tern_value)
    else:                   # SmartIdx
        value[0], value[1] = value[0].cpu().numpy(), value[1].cpu().numpy()
        value_byte = struct.pack('f', value[0]) + struct.pack(('%db' % len(value[1])), *value[1])
    return value_byte+idx_byte

def process(Delta_1d,leng, A_flag, sr, splited_delta,chunk_idx,res_q):
    compress_cost,idx,Nres_q = 0,0,0; pack_cost,meta=[],[]
    if sr!=1:
        s_comp = time.clock()
        idx,value,meta,Nres_q = compression(Delta_1d,leng,sr,A_flag,splited_delta,chunk_idx,res_q)
        compress_cost = round(time.clock() - s_comp, 5)
        idx = idx.cpu().numpy()
        s_pack = time.clock();uploaded = packing(idx,value,A_flag);pack_cost = round(time.clock() - s_pack,5)
    else:
        value = Delta_1d.cpu().numpy()    # 无稀疏化
        s_pack = time.clock();uploaded = struct.pack(('%df' % len(value)), *value);pack_cost = round(time.clock() - s_pack,5)
    all_cost = [compress_cost, pack_cost]
    return uploaded,all_cost,idx, meta,Nres_q


def comm(s,sr,s_flag,uploaded,idx,meta,DwR_1d,residual,shape_list,chunk_idx):
    s.send(struct.pack('I', len(uploaded)))  # 先告诉服务器发送消息的总bit长度
    s.send(uploaded)  # 全部数据
    if int(sr) != 1:
        if s_flag == 0:  # top k
            # residual = DwR_1d   # 采用s_res
            residual[idx] = 0  # 残差积累
        elif s_flag == 1:  # rand k
            pass
        elif s_flag == 3:  # SmartIdx
            s.send(struct.pack('I', len(idx)))  # 告诉服务器消息中 idx 的长度
            s.send(struct.pack('%dI' % int(0.5 * len(shape_list) - 2), *meta[0]))  # 告诉服务器每层有几个索引
            s.send(struct.pack('I', meta[1]))  # 告诉服务器前面多少个是卷积层索引
            idx = np.hstack((get_all(idx[:meta[1]], meta[0], chunk_idx).cpu().numpy(), idx[meta[1]:]))
            residual = DwR_1d
            residual[idx] = 0  # 残差积累
        else:  # RB
            s.send(struct.pack('I', len(idx)))  # 告诉服务器消息中 idx 的长度
            s.send(struct.pack('%dI' % int(0.5 * len(shape_list)), *meta))  # 告诉服务器每层有几个索引
    return residual

