
# def compress1(list):
#     sum = 0
#     out_list = []
#     for i, num in enumerate(list):
#         if i % 8 == 0 and i > 0:
#             out_list.append(sum)
#             sum = 0
#         sum = sum * 2 + num
#     out_list.append(sum)
#     count = 7 - i%8
#     out_list[-1] *= 2**count
#     return out_list, count

def compress(test_list):
    append_num = 8 - len(test_list) % 8
    list = [num*2**(7 - i % 8) for i, num in enumerate(test_list)] + [0 for _ in range(append_num)]
    out_list = [sum(list[8*i:8*i+8]) for i in range(len(test_list)//8 + 1)]
    return out_list, append_num

def decompress(out_list, append_num):
    test_list = []
    for num in out_list:
        binary = list(bin(num).replace('0b',''))
        append_zero = [0 for _ in range(8-len(binary))]
        for i, v in enumerate(binary): binary[i] = int(v)
        test_list.extend(append_zero)
        test_list.extend(binary)
    return test_list[:-append_num]

lists =  [0,0,0,0,1,0,0,1,1,0,1,0,0]

out_list, append_num = compress(lists)  #[9, 160] 3
print(decompress(out_list, append_num))