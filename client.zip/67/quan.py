# -*- coding: UTF-8 -*-
# @Time : 2022/4/14 16:43
# @File : quan.py
# @Software: PyCharm
from  collections import  Counter
import time
from socket import *
import struct
address='10.249.41.141'   #服务器的ip地址
s=socket(AF_INET, SOCK_STREAM)
import torch
import numpy as np
from itertools import chain
from torch.utils.data.sampler import WeightedRandomSampler

def block_sq(float_param):
    st_list = []; bi_list = []; quan_w = [];  bias_sign_list= []
    for p in float_param:
        p = p.cpu().numpy();    scale = 0.75
        if p.ndim != 1:
            b_norm_list = []
            for id, w in enumerate(p):
                b_norm_list.append(np.linalg.norm(w,ord=2))
                p[id] = np.sign(w)
            s_t = scale*np.max(b_norm_list);      st_list.append(s_t/np.sqrt(p.shape[1]))
            prob_1 = np.clip(np.array(b_norm_list) / s_t,a_min=0.00001,a_max=0.9999)
            prob_0 = 1 - prob_1
            prob = np.transpose(np.vstack((prob_0, prob_1)))
            bi = list(WeightedRandomSampler(prob, 1))

            bi =  np.reshape(bi, [len(bi), ]);  bi_list.append(bi)
            for i in range(len(bi)):
                p[i] = bi[i] * p[i]
            quan_w.append(torch.tensor(p,device="cuda:0"))
        else:
            bias_sign_list.append(np.sign(p))
            st_list.append(scale*np.max(np.abs(p)))
    quan_b = []
    for i in range(len(bias_sign_list)):
        quan_b.append(torch.tensor(bi_list[i] * bias_sign_list[i],device="cuda:0"))
    # st_list = list(chain.from_iterable(zip(st_list, st_list)))
    sq_param = list(chain.from_iterable(zip(quan_w, quan_b)))
    print(np.mean(st_list))
    # sq_param.insert(0,torch.tensor(st_list, device="cuda:0"))
    return sq_param,st_list

# def block_sq(float_param):
#     st_list = []; bi_list = []; quan_w = [];  bias_sign_list= []
#     for p in float_param:
#         p = p.cpu().numpy()
#         if p.ndim != 1:
#             prob_1 = []
#             for id, w in enumerate(p):
#                 prob_1.append(np.mean(np.abs(w)/np.max(np.abs(p))))
#                 p[id] = np.sign(w)
#             prob_0 = 1 - np.array(prob_1)
#             st_list.append(0.5*np.max(np.abs(p)))
#             prob = np.transpose(np.vstack((prob_0, prob_1)))
#             bi = list(WeightedRandomSampler(prob, 1))
#
#             bi =  np.reshape(bi, [len(bi), ]);  bi_list.append(bi)
#             for i in range(len(bi)):
#                 p[i] = bi[i] * p[i]
#             quan_w.append(torch.tensor(p,device="cuda:0"))
#         else:
#             bias_sign_list.append(np.sign(p))
#             st_list.append(np.max(np.abs(p)))
#     quan_b = []
#     for i in range(len(bias_sign_list)):
#         quan_b.append(torch.tensor(bi_list[i] * bias_sign_list[i],device="cuda:0"))
#     sq_param = list(chain.from_iterable(zip(quan_w, quan_b)))
#     print(np.mean(st_list))
#     # sq_param.insert(0,torch.tensor(st_list, device="cuda:0"))
#     return sq_param,st_list

def sq(DwR_1d):
    DwR_abs = torch.abs(DwR_1d)
    s_t = torch.max(DwR_abs)
    sign = torch.sign(DwR_1d)
    prob_1 = DwR_abs / s_t
    prob_0 = 1 - prob_1
    prob = torch.t(torch.vstack((prob_0,prob_1)))
    bi = list(WeightedRandomSampler(prob, 1))
    bi = torch.tensor(np.reshape(bi,[len(bi),]),device="cuda:0")
    sign = bi*sign
    sign = sign.type(torch.int8)
    return [s_t,sign]


def qd(delta,num_layer,q):
    model_1d = [] ;s_list = []; z_list = [];k=0
    for i,num in enumerate(num_layer):
        layer_1d = np.asarray(delta[k:k + num])
        s = (np.max(layer_1d)  - np.min(layer_1d) ) / (np.power(2, q-1))
        z = - (np.min(layer_1d) / s)
        int_layer_1d =  np.round(layer_1d / s + z)
        model_1d.append(int_layer_1d.astype(np.uint8))
        s_list.append(s);z_list.append(z)
        k+=1
    model_1d = np.array(list(chain.from_iterable(model_1d)))
    s_byte = struct.pack(('%df' % len(s_list)), *s_list)
    z_byte = struct.pack(('%df' % len(z_list)), *z_list)
    param_byte = struct.pack(('%dB' % len(model_1d)), *model_1d)
    '''模拟恢复'''
    # k=0;restored_1d=[]
    # for i, num in enumerate(num_layer):
    #     int_layer = np.asarray(model_1d[k:k + num])
    #     restore_layer = s_list[i] * (int_layer - z_list[i])
    #     restored_1d.append(restore_layer)
    #     k += num
    # restored_1d = np.array(list(chain.from_iterable(restored_1d)))
    # diff = np.sign(restored_1d)-np.sign(delta)
    # print('符号错误{}个'.format(np.size(np.nonzero(diff))))
    return  s_byte+z_byte+param_byte # 大写字母 无符号