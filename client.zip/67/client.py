
import time
from socket import *
import struct
import argparse
address='10.249.41.141'   #服务器的ip地址
s=socket(AF_INET, SOCK_STREAM)
import pandas as pd
from math import floor
import torch
import torch.nn.functional as F
import numpy as np
import torchvision.transforms as transforms
import torchvision.datasets as dset
import socket as skt
from utils import net2vec,vec2net,net_split,process,get_num_correct,get_interval,idx_container,comm,shape_1d,tensor_layer_num,get_all
from model import ResNet18,NET,VGG
import torchvision.models as MODEL


image_size = (32,32)
batch_size = 100
transform=transforms.Compose([
    transforms.RandomHorizontalFlip(),
    transforms.Resize(image_size),
    transforms.CenterCrop(image_size),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
])
train_data=dset.CIFAR10(root='data/CIFAR10',train=True,transform=transform,download=True)
test_data=dset.CIFAR10(root='data/CIFAR10',train=False,transform=transform,download=True)
train_loader=torch.utils.data.DataLoader(train_data,batch_size=batch_size,shuffle=True)
test_loader=torch.utils.data.DataLoader(test_data,batch_size=batch_size,shuffle=True)
train_len=len(train_data)
test_len=len(test_data)
print(train_len,test_len)
n_classes=10
st = []


def train(model, device,sr, epoch_num):
    InitalModel_1d = net2vec(model)
    optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
    # optimizer = torch.optim.Adam(model.parameters())
    test_acc_list = []; train_acc_list = []
    residual = torch.zeros(leng).to(device); res_q = torch.zeros(leng).to(device)
    if s_flag == 2 or s_flag == 3: chunk_idx = idx_container(interval, shape_list,device)
    else:           chunk_idx = []
    for epoch in range(epoch_num):
        total_loss = 0;train_correct = 0;test_correct = 0
        if epoch == 0: TrainBefore_1d = InitalModel_1d
        else:          TrainBefore_1d = NewModel_1d
        s_train = time.clock()
        for step, batch in enumerate(train_loader):
            images, labels = batch
            images, labels = images.to(device), labels.to(device)
            outs = model.forward(images)
            loss = F.cross_entropy(outs, labels)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
            train_correct += get_num_correct(outs, labels)
        for step, batch in enumerate(test_loader):
            images, labels = batch
            images, labels = images.to(device), labels.to(device)
            outs = model.forward(images)
            test_correct += get_num_correct(outs, labels)
        # print('training time',time.clock()-s_train)
        train_acc = train_correct / train_len; test_acc = test_correct / test_len
        train_acc_list.append(train_acc); test_acc_list.append(test_acc)
        print("第{}轮训练结果：loss:".format(epoch), round(total_loss,2), " train_correct:", round(train_acc,3), " test_correct:", round(test_acc,3))
        DwR_1d = (TrainBefore_1d - net2vec(model)) + residual
        if (s_flag>1) and int(sr)!=1:  splited_DwR = net_split(DwR_1d,shape_list)
        else:                          splited_DwR = 0
        count, bb = tensor_layer_num(shape_list) # for smt
        uploaded, cost, idx, meta,res_q,value,residual_bird = process(DwR_1d,leng, s_flag, sr,splited_DwR,chunk_idx,res_q,bb)
        # if s_flag == 2: st.append(value[2])
        print('压缩总耗时{}s,稀疏耗时{}s,量化耗时{}s,編碼耗时{}s,打包耗时{}s'.format(cost[0],cost[1],cost[2],cost[3],cost[4]))
        # sg = time.time(); ff = get_all(idx, meta, chunk_idx, bb); print(time.time()-sg)
        residual = comm(s,sr,s_flag,uploaded,idx,meta,DwR_1d,splited_DwR,residual,bb,chunk_idx)
        # if s_flag==2: residual = residual_bird
        recv = s.recv(4*leng, skt.MSG_WAITALL)
        global_delta_1d = struct.unpack(('%df' % int(len(recv)/4)),recv)
        NewModel_1d = TrainBefore_1d - torch.tensor(global_delta_1d).to(device)
        updated_model = vec2net(NewModel_1d,shape_list)
        for layer,param in enumerate(model.parameters()):
            param.data = updated_model[layer].clone().detach().requires_grad_(True).type(torch.FloatTensor).to(device)

        # dir = '/home/wdl/project/fedpipe/data/'
        # data = []
        # data.append(test_acc_list); data.append(train_acc_list)
        # row = ['test', 'train']
        # save_file = pd.DataFrame(index=row, data=data)
        # save_file.to_csv(dir + '{}.csv'.format(filename), index=False, encoding="utf-8")
    print('test acc{}'.format(test_acc_list))
    # if s_flag ==2: print('st',st)

parser = argparse.ArgumentParser()
parser.add_argument('--s', help='s_flag', type=int, default=4)
parser.add_argument('--sr', help='sparse ratio', type=float, default=0.1) #1e-1
parser.add_argument('--p', help='port', type=int, default=3333)
parser.add_argument('--n', help='file name', type=str, default='')
parser.add_argument('--e', help='epoch', type=int, default=30)
parser.add_argument('--t', help='task', type=str, default='cv')
args = vars(parser.parse_args())
s_flag = args['s']; sr = args['sr'];port=args['p']; filename = args['n']; epoch = args['e']; task = args['t']
shape_list = [];num_layer=[]
torch.manual_seed(1)
if task=='sp':
    leng  = 15253578  #  681546  2693898  15253578
    net = VGG('VGG16')
elif task=='cv':
    leng  = 11310474
    net = ResNet18( n_classes)
else:
    leng  = 31043286
    net =  NET(batch_size, n_classes)
for param in net.parameters():
    shape_list.append(param.data.shape)
    num_layer.append(np.prod(np.array(param.data.shape)))

interval = get_interval(num_layer)

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
net.to(device)
dim_size, shape_list_1d = shape_1d(shape_list)

s.connect((address, port))
print('connection has been built')
s.send(struct.pack('I', leng) + struct.pack('I', len(shape_list))+ struct.pack('I', len(shape_list_1d)))
s.send(struct.pack('%dI' % (len(dim_size)+len(shape_list_1d)+len(num_layer)),*dim_size+shape_list_1d+num_layer))   # meta3

train(net,device,sr,epoch)