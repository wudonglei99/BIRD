import struct
import numpy as np
import torch


class Node:
  def __init__(self):
    self.frequency=0
    self.name=None
    self.lchild=None
    self.rchild=None
    self.code=None
  def __lt__(self,other):
    return self.frequency < other.frequency

class HuffmanCoder():
  def __init__(self):
    pass

  # establish the Huffman Tree
  def estblishHuffmanTree(self, info_dict):
    node_list=[]
    for i in info_dict:
      a = Node()
      a.frequency = info_dict[i]
      a.name = i
      node_list.append(a)
    while len(node_list) > 1:
      node_list.sort(reverse=True)
      node_1 = node_list.pop()
      node_2 = node_list.pop()
      new_node = Node()
      new_node.frequency = node_1.frequency + node_2.frequency
      new_node.lchild = node_1
      new_node.rchild = node_2
      node_list.append(new_node)
    return node_list[0]

  # left branch is 0, right branch is 1
  def encode(self, node, rst_dict, code):
    if node == None:
      return
    if node.name != None:
      if code == '':
        rst_dict.update({node.name:'0'})
        return rst_dict
      rst_dict.update({node.name:code})
      return
    code+='0'
    self.encode(node.lchild,rst_dict,code)
    code = code[:-1]
    code+='1'
    self.encode(node.rchild,rst_dict,code)
    return rst_dict

class SKEncoder():
    def __init__(self, values=None, keys=None, device='cpu'):
        self.huffman_coder = HuffmanCoder()
        self.origin_keys = keys
        self.origin_gradient = values
        self.device = device
        self.sketch_s = 2
        self.sketch_m = 3000
        # self.hashset = {
        #     0:lambda key:(key % 247)**2 % self.sketch_m,
        #     1:lambda key:(key % 161)**3 % self.sketch_m,
        # }
        self.hashset = {
            0:lambda key:((((key**3 % 247) + (13*key%271))))**2 % self.sketch_m,
            1:lambda key:(((key**2 % 161) + (19*key%171)))**3 % self.sketch_m,
        }

    def _reset(self):
        self.hash_table = np.full((self.sketch_s, self.sketch_m), self.origin_keys.shape[0])
        self.keys = None
        self.gradient = None
        self.delta_keys = None

        self.prefix_dict = None
        self.gradient2bucketsid = None
        self.buckets_mean = None
        self.hashtable_freq_dict = None
        self.prefix_intervalid = None
        self.intervalid2prefix = None
        self.interval_size = None

        self.hashtable_code = None
        self.prefix_code = None
        self.delta_keys_code = None

    def set_sign(self, mode='pos'):
        self.mode = mode
        if mode == 'pos':
            self._reset()
            self.pos_index = (self.origin_gradient >= 0).to(self.device)
            self.keys = self.origin_keys[self.pos_index].to(self.device)
            self.gradient = self.origin_gradient[self.pos_index].to(self.device)
            if self.keys.shape[0]:
                self.delta_keys = self._get_delta_keys()
        elif mode == 'neg':
            self._reset()
            self.neg_index = (self.origin_gradient < 0).to(self.device)
            self.keys = self.origin_keys[self.neg_index].to(self.device)
            self.gradient = -self.origin_gradient[self.neg_index].to(self.device)
            if self.keys.shape[0]:
                self.delta_keys = self._get_delta_keys()
        else:
            raise ValueError("mode should be 'pos' or 'neg'")
        return True if self.keys.shape[0] else False

    def _get_freq_list(self, table):
        freq_dict = {}
        items, count = np.unique(table, return_counts=True)
        freq_dict = {items[i]:count[i] for i in range(items.shape[0])}
        return freq_dict

    def _get_delta_keys(self):
        delta_keys = torch.hstack((torch.tensor([self.keys[0]]).to(self.device), torch.diff(self.keys).to(self.device))).to(self.device)
        return delta_keys

    def _prefix_ready(self, num_interval=8):
        bits_per_interval = int(32 / num_interval)
        self.interval_size = bits_per_interval
        prefix_len = int(np.log2(num_interval))
        prefix_dict = {}
        for interval in range(num_interval):
            prefix_code = bytes('', encoding='utf-8')
            for i in range(prefix_len):
                prefix_code += bytes(str(((1 << (prefix_len-i-1)) & interval) >> (prefix_len-i-1)), encoding='utf-8')
            prefix_dict[2**((interval+1)*bits_per_interval)-1] = prefix_code
        return prefix_dict


    def compress2index(self, q=4):
        ranks = torch.arange(1/q, 1+1/q, 1/q).to(self.device)
        quantile_bound = torch.quantile(self.gradient, ranks).to(self.device)

        gradient2bucketsid = torch.zeros(self.gradient.shape[0]).to(self.device)
        for id, bound in enumerate(quantile_bound):
            comp_res = self.gradient <= bound
            if id == 0:
                pre_comp = comp_res
            else:
                comp_res = torch.logical_and(~pre_comp, comp_res).to(self.device)
                pre_comp = torch.logical_or(pre_comp, comp_res).to(self.device)
            gradient2bucketsid[comp_res] = id

        quantile_bound = torch.hstack((torch.min(self.gradient).to(self.device), quantile_bound)).to(self.device)
        buckets_mean = (quantile_bound[:-1] + quantile_bound[1:]) / 2

        self.gradient2bucketsid = gradient2bucketsid.to(torch.int32)
        self.buckets_mean = buckets_mean if self.mode == 'pos' else -buckets_mean

    def minmaxsketch_insert(self):
        for row in range(self.sketch_s):
            key_str = self.keys.cpu().numpy().astype(np.int32)
            cols = self.hashset[row](key_str)
            unique_cols= np.unique(cols.astype(np.int32))
            for i in range(unique_cols.shape[0]):
                bucketsid_list = np.where(cols == unique_cols[i], self.gradient2bucketsid.cpu().numpy(), self.keys.shape[0])
                final_value = np.min(bucketsid_list)
                table_value = self.hash_table[row][unique_cols[i]]
                if table_value > final_value:
                    self.hash_table[row][unique_cols[i]] = final_value


    def huffman_code(self, mode='prefix', display=False):
        if mode == 'prefix':
            tablelist = self.prefix_intervalid
        elif mode == 'hashtable':
            tablelist = self.hash_table.flatten()
        else:
            raise ValueError("mode should be 'prefix' or 'hashtable'")

        tablelist_freq_dict = self._get_freq_list(tablelist)
        tablelist_root_node = self.huffman_coder.estblishHuffmanTree(tablelist_freq_dict)
        tablelist_code_dict = self.huffman_coder.encode(tablelist_root_node, {}, '')
        tablelist_code = [tablelist_code_dict[tablelist[i]] for i in range(tablelist.shape[0])]
        tablelist_code = "".join(tablelist_code)
        if mode == 'prefix':
            self.prefix_code = tablelist_code.encode('utf-8')
            self.intervalid2prefix = tablelist_code_dict
        else:
            self.hashtable_code = tablelist_code.encode('utf-8')
            self.hashtable_freq_dict = tablelist_freq_dict
            self.hashtable_code_dict = tablelist_code_dict
        
        if display:
            print('-------------------------huffman code display')
            if mode == 'hashtable':
                print("original:\n", tablelist.reshape(self.sketch_s, self.sketch_m))
            print("huffman coding:")
            for key in tablelist_code_dict:
                print("{} encode to {}".format(key, tablelist_code_dict[key]))

    def get_fixed_prefix(self, interval_num=8, display=False):
        self.prefix_dict = self._prefix_ready(interval_num)
        prefix_intervalid = []
        intervalid2prefix = {}
        for key in self.delta_keys:
            for intervalid, upbound in enumerate(self.prefix_dict):
                if key <= upbound:
                    prefix_intervalid.append(intervalid)
                    intervalid2prefix[intervalid] = self.prefix_dict[upbound]
                    break
        prefix_intervalid = np.asarray(prefix_intervalid, dtype=np.int32)
        self.prefix_intervalid = prefix_intervalid
        self.intervalid2prefix = intervalid2prefix
        fixed_prefix_code = ''
        self.delta_keys_code = self._deltakeys_to_binary_str(int(32/interval_num))

        if display:
            print("-------------------------fixed prefix display")
            for interval_id in prefix_intervalid:
                print("{} prefix is {}".format(interval_id, intervalid2prefix[interval_id]))
            print("interval id:", end=' ')
            for interval_id in prefix_intervalid:
                print(interval_id, end=' ')
            print("\nfixed prefix code:", fixed_prefix_code)
    
    def get_adaptive_prefix(self, interval_num=8, display=False):
        self.prefix_dict = self._prefix_ready(interval_num)
        prefix_intervalid = torch.zeros(self.delta_keys.shape[0]).to(self.device)

        for interval_id, upbound in enumerate(self.prefix_dict):
            comp_res = self.delta_keys <= upbound
            if interval_id == 0:
                pre_comp = comp_res
            else:
                comp_res = torch.logical_and(~pre_comp, comp_res).to(self.device)
                pre_comp = torch.logical_or(pre_comp, comp_res).to(self.device)
            prefix_intervalid[comp_res] = interval_id
        self.prefix_intervalid = prefix_intervalid.cpu().numpy()
        self.huffman_code(mode='prefix', display=False)
        # self.delta_keys_code = self._deltakeys_to_binary_str(int(32/interval_num))
        self.delta_keys_code = struct.pack('%di'%len(self.delta_keys), *self.delta_keys.cpu().numpy())


    def _deltakeys_to_binary_str(self, interval_size):
        code = []
        expected_len = (self.prefix_intervalid+1) * interval_size
        for keyid in range(self.delta_keys.shape[0]):
            number2str = bin(self.delta_keys[keyid].item()).replace('0b', '')
            str_len = len(number2str)
            if str_len < expected_len[keyid]:
                padding = int(expected_len[keyid] - str_len)
                number2str = '0'*padding + number2str
            code.append(number2str)
        code = "".join(code)
        return bytes(code)

  # three things need to be transmitted: hash table encoded by huffman code, bucket mean and delta keys with prefix 
    def transmit(self, display=False):
        info = {
            'buckets_mean':self.buckets_mean,
            'hashtable_code':self.hashtable_code,
            'prefix_code':self.prefix_code,
            'delta_keys_code':self.delta_keys_code, 
            'interval_size':self.interval_size,
            'keys_grads_len':self.keys.shape[0],
            'intervalid2prefix':self.intervalid2prefix,
            'hashtable_code_dict':self.hashtable_code_dict,
        }
        if display:
            print("-------------------------transmit display")
            for key in info:
                print("{} encoded as {}".format(key, info[key]))
            print("transmission finish")
        return info
