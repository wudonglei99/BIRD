import numpy as np
import mmh3,torch
mmh3.hash('123') # hash output is a 32-bit signed int

def generate_hash_table(capacity, num_hash):
    table = []
    for ii in range(capacity):
        row = []
        for jj in range(num_hash):
            row.append(mmh3.hash(str(ii), jj))
        table.append(row)
    return np.asarray(table)

hash_table = torch.tensor(generate_hash_table(600000000,10),).int() #int32
torch.save(hash_table, "./hash_table_183m.pt", _use_new_zipfile_serialization=False)