from Tobytes import tobytes
import torch

# path: the path where the tobytestool.so exists
# tensor: the tensor for processing 
# return: signigicant bit length,  0b'xff\xff......'
tensor = torch.ones(30000000)
path = './tobytestool.so'
length, resbytes = tobytes(path, tensor)
#print(resbytes, length)

