#include <stdio.h>
#include <stdlib.h>


void numtobytes(int *number, unsigned int length, char *buffer_in){
    unsigned char sign = 0x80;
    int round = 0;
    for(int count = 0; count < length;){
        unsigned char block = 0;
        int count_mod = 0;
        int end = count + 8;
        while(count < end && count < length){
            block = ((number[count] & sign) >> count_mod) | block;
            count++;
            count_mod++;
        }
        buffer_in[round] = block;
        round++;
    }
    buffer_in[round] = '\0';
}

void bytestonum(char *bytesnum, unsigned int length, int *buffer_out){
    int bytes_array_length = (length >> 3) + 1;
    int total_len = 0;
    for(int i = 0; i < bytes_array_length; i++){
        int count = 7;
        while(count >= 0 && total_len < length){
            if((1<<count) & bytesnum[i])    buffer_out[total_len] = -1;
            else                            buffer_out[total_len] = 1;
            count--;
            total_len++;
        }
    }
}
