from Tobytes import tobytes
import torch
# import os
# print(os.sys.path)

# path: the path where the tobytestool.so exists
# tensor: the tensor for processing 
# return: signigicant bit length,  0b'xff\xff......'
tensor = torch.ones(30000000)*-1
path = '/home/wdl/project/fedpipe/tobytestool.so'
length, resbytes = tobytes(path, tensor)

print(resbytes, length)

