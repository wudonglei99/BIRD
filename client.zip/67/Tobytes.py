import time
from ctypes import *
import numpy as np
from math import ceil


def tobytes(load_path, tensor):
    # t0 = time.perf_counter()
    lib = CDLL(load_path)
    lib.numtobytes.argtypes = [POINTER(c_int), c_uint, POINTER(c_char)]
    length_array = tensor.shape[0]
    pyarray = tensor.astype(np.int32)
    carray = pyarray.ctypes.data_as(POINTER(c_int))
    length_carray = c_uint(length_array)
    waitfill_length = ceil(length_array / 8) + 1
    waitfill_carray = (c_char * waitfill_length)()
    lib.numtobytes(carray, length_carray, waitfill_carray)
    # t5 = time.perf_counter()
    # print("total time = " + str(t5-t0))
    return length_array, bytes(waitfill_carray)


def tonum(load_path, length_array, pyarray):
    # t0 = time.perf_counter()
    lib = CDLL(load_path)
    lib.bytestonum.argtypes = [POINTER(c_char), c_uint, POINTER(c_int)]
    carray = c_char_p(pyarray)
    length_carray = c_uint(length_array)
    waitfill_carray = (c_int * length_array)()
    lib.bytestonum(carray, length_carray, waitfill_carray)
    # t5 = time.perf_counter()
    # print("total time = " + str(t5-t0))
    return np.array(waitfill_carray, dtype=np.int32)
