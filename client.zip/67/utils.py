

import time
from socket import *
import struct
from quan import sq,block_sq,qd
address='10.249.41.141'   #服务器的ip地址
s=socket(AF_INET, SOCK_STREAM)
from math import floor,ceil
import torch
import numpy as np
from itertools import chain
import random
import lzma
from torch.utils.data.sampler import WeightedRandomSampler
from grace import deepreduce,helper





def get_num_correct(out, labels):  #求准确率
    return out.argmax(dim=1).eq(labels).sum().item()

def shape_1d(shape_list):
    shape_1d = []; dim_size = []
    for dim in shape_list:
        dim_size.append(len(dim))
        for item in dim:
            shape_1d.append(item)
    return dim_size, shape_1d



def get_interval(flatten_list):
    sum = 0; interval = []
    for l in flatten_list:
        sum += l
        interval.append(sum)
    return interval

def vec2net(vec, shape_list):
    k = 0
    net = []
    for item in shape_list:
        temp = 1
        for _ in range(len(item)):
            temp *= item[_]
        param_1D = vec[k:k + temp]
        param = torch.reshape(param_1D, item)
        net.append(param)
        k += temp
    return net

def net2vec(model):
    model_1d = []
    for layer in model.parameters():
        layer_1d = torch.flatten(layer.data)
        model_1d.append(layer_1d)
    out = torch.cat((model_1d[0],model_1d[1]),0)
    for j in range(2,len(model_1d)):
        out = torch.cat((out, model_1d[j]), dim=0)
    return out

def idx_container(interval,shape_list,device):
    layer_idx = []; start = 0; chunk_idx = []
    for i in range(len(interval)):
        layer_idx.append(torch.tensor(list(range(start,interval[i])),device=device))
        start = interval[i]
    for j, layer in enumerate(layer_idx):
        layer_with_chunk = []
        if len(shape_list[j])!=1:
            chunk_len = np.prod(np.array(shape_list[j])[1:])
            for k in range(shape_list[j][0]):
                layer_with_chunk.append(layer[k*chunk_len:(k+1)*chunk_len])
        else:
            layer_with_chunk.append(layer)
        chunk_idx.append(layer_with_chunk)
    return chunk_idx

# def get_all(idx,layer_num,chunk_idx):
#     start = 0; tmp = []; i=0
#     for num in layer_num:
#         w = list(np.array(chunk_idx[i * 2])[idx[start:start + num]])
#         w.append(chunk_idx[i*2+1][0][idx[start:start+num]])  #  添加bias 的 index
#         tmp.append(w)
#         start=start+num;       i+=1
#     tmp = (list(chain.from_iterable(tmp)))
#     all_idx = torch.cat((tmp[0],tmp[1]), dim=0)
#     for item in tmp[2:]:
#         all_idx = torch.cat((all_idx,item), dim=0)
#     return all_idx

def get_all(idx,layer_num,chunk_idx,bias_bn):
    start = 0; tmp = []; i=0;k=0
    for num in layer_num:
        w = list(np.array(chunk_idx[i])[idx[start:start + num]])
        i+=1
        for j in range(bias_bn[k]):
            w.append(chunk_idx[i+j][0][idx[start:start+num]])
        tmp.append(w)
        start=start+num
        i+=bias_bn[k]
        k+=1
    tmp = (list(chain.from_iterable(tmp)))
    all_idx = torch.cat((tmp[0],tmp[1]), dim=0)
    for item in tmp[2:]:
        all_idx = torch.cat((all_idx,item), dim=0)
    return all_idx

def tensor_layer_num(shape_list):
    i = 0;bias_bn = [];bb=0
    for id, item in enumerate(shape_list):
        if len(item)!=1:
            if id!=0:
                bias_bn.append(bb)
            bb=0
            i+=1  # 記錄有多少非 bb   layer
        else:
            bb+=1
        if id ==len(shape_list)-1:
            bias_bn.append(bb)
    return i,bias_bn

def net_split(DwR_1d,shape_list):
    DwR = vec2net(DwR_1d, shape_list)
    conv = []; fc = []; bias = []
    i = 0
    for layer in DwR:
        if len(layer.data.shape)==4:
            conv.append(torch.flatten(layer.data,start_dim=1))
            bias.append([])
            i+=1
        elif len(layer.data.shape)==2:
            fc.append(layer.data)
            bias.append([])
            i+=1
        else:
            bias[i-1].append(layer.data)
    return [conv, fc,bias]

# def net_split(DwR_1d,shape_list):
#     DwR = vec2net(DwR_1d, shape_list)
#     conv = []; fc = []; bias = []
#     for layer in DwR:
#         if len(layer.data.shape)==4:   conv.append(torch.flatten(layer.data,start_dim=1))
#         elif len(layer.data.shape)==2: fc.append(layer.data)
#         else:                          bias.append(layer.data)
#     return [conv, fc,bias]

def statistical(idx,interval):
    layer_in = np.zeros(len(interval))
    for i in idx:
        for j in range(len(interval)):
            if interval[j]< i <interval[j+1] or 0 < i <interval[j]:
                layer_in[j]+=int(1)
                break
    return layer_in

def smartidx(DwR_1d,splited_DwR, sr,leng, chunk_idx,bb):
    DwR_1d = DwR_1d.cpu()
    s_sp = time.clock()
    var_abs = torch.abs(DwR_1d)
    _, topk_1d = torch.topk(var_abs, floor(sr * leng))
    topk_1d = set(topk_1d.cpu().numpy().tolist())
    conv_chunk = chunk_idx[:sum(bb[:len(splited_DwR[0])])+len(splited_DwR[0])]
    # n = 0
    # for layer in range(len(splited_DwR[0])):
    #     n+=torch.prod(torch.tensor(splited_DwR[0][layer].shape))  # 計算Conv layer 參數量
    # conv_idx_list = set(list(range(n)))
    conv_idx_list=[]
    for layer in chunk_idx[:sum(bb[:len(splited_DwR[0])])+len(splited_DwR[0])]:
        if len(layer)!=1:
            layer1 = []
            for l in layer:
                layer1.append(l.cpu().numpy())
            conv_idx_list.append(list(chain.from_iterable(layer1)))
    conv_idx_list = list(chain.from_iterable(conv_idx_list))
    top_conv =set(conv_idx_list).intersection(topk_1d)
    top_weight = torch.tensor(list(topk_1d-top_conv),device="cuda:0")

    layer_block_num = []; conv_idx = []
    for layer in conv_chunk:
        id_list=[]
        if len(layer)!=1:
            for id, filter in enumerate(layer):
                filter = set(filter.cpu().numpy())
                if len(filter.intersection(top_conv))!=0:
                    id_list.append(id)
            conv_idx.append(id_list);layer_block_num.append(len(id_list))
    conv_idx = list(chain.from_iterable(conv_idx))

    all_conv_idx = get_all(conv_idx, layer_block_num, chunk_idx,bb)
    all_idx = torch.cat((all_conv_idx,top_weight),0)
    s_cost = round(time.clock()-s_sp,2)
    s_quan = time.clock()
    quaned_value = [torch.mean(torch.abs(DwR_1d[all_idx])), torch.sign(DwR_1d[all_idx]).type(torch.int8)]
    uploaded_idx = torch.cat((torch.tensor(conv_idx,device="cuda:0"),top_weight),0)
    q_cost = round(time.clock()-s_quan,2)
    return uploaded_idx, quaned_value, [layer_block_num, len(conv_idx)],[s_cost,q_cost]


def RB(splited_DwR,sr):
    st_list_s=[]; st_list=[]; selected_block=[];selected_bias=[]; block_idx = []; layer_block_num=[]
    q_time = []; s_time = []
    for i,block_layer in enumerate(splited_DwR[0]+splited_DwR[1]):
        '''第一次随机量化'''
        s_quan = time.clock()
        norm_list = torch.norm(torch.abs(block_layer), dim=1,p=2)
        s_t =  torch.max(norm_list)
        prob_1 =  norm_list / s_t
        prob_0 = 1 - prob_1
        prob = torch.t(torch.vstack((prob_0, prob_1)))
        bi = list(WeightedRandomSampler(prob, 1))
        bi = torch.tensor(np.reshape(bi, [len(bi), ]),device="cpu")
        big_norm_idx = torch.where(bi > 0)[0]
        q_time.append(time.clock()-s_quan)
        '''第二次稀疏化'''
        s_sp = time.clock()
        if len(big_norm_idx) > ceil(sr * len(block_layer)):
            '''topk'''
            # _, IdxOfIdx = torch.sort(norm_list[big_norm_idx])
            # IdxOfIdx = IdxOfIdx[-ceil(sr * len(block_layer)):]
            # idx = big_norm_idx[IdxOfIdx]
            '''rand-k'''
            IdxOfIdx = torch.randperm(len(big_norm_idx),device="cpu")[:ceil(sr * len(block_layer))]
            idx = big_norm_idx[IdxOfIdx]
            '''all'''
            # idx = big_norm_idx
        else:
            idx = big_norm_idx
        if len(idx) == 0:
            layer_block_num.append(0)
        else:
            idx, _ = torch.sort(idx)
            selected_block.append(block_layer[idx])
            st_list.append((s_t/np.sqrt( block_layer.shape[1]))*(1/(len(idx)/len(big_norm_idx))))
            # st_list.append((s_t/np.sqrt( block_layer.shape[1])) )
            selected_bias.append([])
            for item in splited_DwR[2][i]:
                selected_bias[i].append(item[idx])
                st_list.append((s_t/np.sqrt(block_layer.shape[1]))*(1/(len(idx)/len(big_norm_idx))))
                # st_list.append((s_t/np.sqrt( block_layer.shape[1])) )
            block_idx.append(idx); layer_block_num.append(len(idx))#; layer_num.append(len(idx))
        s_time.append(time.clock()-s_sp)
    s_cost = round(sum(s_time),4);q_cost = round(sum(q_time),2)
    '''获取实际上传索引 1d'''
    idx_1d = torch.cat((block_idx[0], block_idx[1]), 0)
    for j in range(2, len(block_idx)):
        idx_1d = torch.cat((idx_1d, block_idx[j]), dim=0)
    '''获取实际上传参数值 1d'''
    s_q2 = time.clock()
    selected_param = list(chain.from_iterable(zip(selected_block, selected_bias)))
    selected_param_sign=[]
    for item in selected_param:
        if isinstance(item,list)==1:
            for it in item:
                selected_param_sign.append(torch.sign(it))   #  bias   bn
        else:
            selected_param_sign.append(torch.sign(item))     #  tensor
    q_cost+=round(time.clock()-s_q2,2)
    # st_list = st_list_s*np.array(st_list_q)
    # st_list = list(chain.from_iterable(zip(st_list, st_list)))  # 只適合無bn層的網絡（舊版本）

    value_1d = torch.cat((torch.flatten(selected_param_sign[0]), torch.flatten(selected_param_sign[1])), 0)
    for j in range(2, len(selected_param_sign)):
        value_1d = torch.cat((value_1d, torch.flatten(selected_param_sign[j])), dim=0)

    value_1d = value_1d.type(torch.int8)
    st_list = torch.tensor(st_list, device="cuda:0")
    return idx_1d,[st_list,value_1d,st_list_s],layer_block_num,[s_cost,q_cost]

# def RB(splited_DwR,sr):
#     st_list_q=[]; st_list_s=[]; selected_block=[];selected_bias=[]; block_idx = []; layer_block_num=[]
#     q_time = []; s_time = []
#     for i,block_layer in enumerate(splited_DwR[0]+splited_DwR[1]):
#         '''第一次随机量化'''
#         s_quan = time.clock()
#         norm_list = torch.norm(torch.abs(block_layer), dim=1,p=2)
#         s_t =  torch.max(norm_list);      st_list_q.append(s_t/np.sqrt( block_layer.shape[1]))
#         prob_1 =  norm_list / s_t
#         prob_0 = 1 - prob_1
#         prob = torch.t(torch.vstack((prob_0, prob_1)))
#         prob = prob.cpu()
#         bi = list(WeightedRandomSampler(prob, 1))
#         bi = torch.tensor(np.reshape(bi, [len(bi), ]),device="cpu")
#         big_norm_idx = torch.where(bi>0)[0]
#         q_time.append(time.clock()-s_quan)
#         '''第二次随机稀疏化'''
#         s_sp = time.clock()
#         if len(big_norm_idx) > ceil(sr * len(block_layer)):
#             IdxOfIdx = torch.randperm(len(big_norm_idx),device="cpu")[:ceil(sr * len(block_layer))]
#             idx = big_norm_idx[IdxOfIdx]
#         else:
#             idx = big_norm_idx
#         st_list_s.append(1/(len(idx)/len(big_norm_idx)))
#         if len(idx) == 0:
#             layer_block_num.append(0)
#         else:
#             idx, _ = torch.sort(idx)
#             selected_block.append(block_layer[idx])
#             selected_bias.append(splited_DwR[2][i][idx])
#             block_idx.append(idx); layer_block_num.append(len(idx))#; layer_num.append(len(idx))
#         s_time.append(time.clock()-s_sp)
#     print('稀疏化耗時{}，量化耗時{}'.format(round(np.sum(s_time),4),round(np.sum(q_time),4)))
#     '''获取实际上传索引'''
#     idx_1d = torch.cat((block_idx[0], block_idx[1]), 0)
#     for j in range(2, len(block_idx)):
#         idx_1d = torch.cat((idx_1d, block_idx[j]), dim=0)
#     '''获取实际上传参数值'''
#     selected_param = list(chain.from_iterable(zip(selected_block, selected_bias)))
#     selected_param_sign=[]
#     for item in selected_param:
#         selected_param_sign.append(torch.sign(item))
#     st_list = st_list_s*np.array(st_list_q)
#     st_list = list(chain.from_iterable(zip(st_list, st_list)))
#
#     value_1d = torch.cat((torch.flatten(selected_param_sign[0]), torch.flatten(selected_param_sign[1])), 0)
#     for j in range(2, len(selected_param_sign)):
#         value_1d = torch.cat((value_1d, torch.flatten(selected_param_sign[j])), dim=0)
#
#     value_1d = value_1d.type(torch.int8)
#     st_list = torch.tensor(st_list, device="cuda:0")
#     return idx_1d,[st_list,value_1d,st_list_s],layer_block_num,[0,0]



def sbc(DwR_1d, sr, leng):
    '''稀疏化'''
    DwR_1d=DwR_1d.cpu()
    s_sp = time.clock()
    DwR_abs = torch.abs(DwR_1d)
    _, idx = torch.topk(DwR_abs, floor(sr * leng))
    idx, _ = torch.sort(idx)
    s_cost = round(time.clock()-s_sp,2)
    '''量化'''
    s_quan = time.clock()
    value_info = [torch.mean(DwR_abs[idx]), torch.sign(DwR_1d[idx]).type(torch.int8)]
    q_cost = round(time.clock()-s_quan,2)
    # pos_ind = torch.where(DwR_1d[idx] > 0)[0]
    # neg_ind = torch.where(DwR_1d[idx] <= 0)[0]
    # pos_mean = torch.mean(DwR_abs[idx[pos_ind]])
    # neg_mean = torch.mean(DwR_abs[idx[neg_ind]])
    # if pos_mean>neg_mean:
    #     index = idx[pos_ind]
    #     value_info = [torch.mean(DwR_abs[index]),torch.sign(DwR_1d[index]).type(torch.int8)]
    # else:
    #     index = idx[ neg_ind]
    #     value_info = [torch.mean(DwR_abs[index]),torch.sign(DwR_1d[index]).type(torch.int8)]
    # q_cost = round(time.clock()-s_quan,2)
    return idx, value_info, [s_cost,q_cost]


def get_residual(DwR_1d,idx, layer_num, chunk_idx, bb, binary_1d,leng,num_layer,st_list):
    tmp = torch.zeros(leng, device="cuda:0")
    all_idx = get_all(idx, layer_num,  chunk_idx, bb)
    tmp[all_idx] = binary_1d.type(torch.float)
    split_tmp = torch.split(tmp, num_layer)
    recovered_model = []
    for i in range(len(st_list)):
        recovered_model.append(split_tmp[i] * st_list[i])
    out = torch.cat((recovered_model[0], recovered_model[1]))
    for j in range(2, len(recovered_model)):
        out = torch.cat((out, recovered_model[j]))
    residual = DwR_1d-out

    return residual


def compression(DwR_1d,leng,sr,A_flag,splited_DwR,chunk_idx,res_q,bb):
    meta = []; Nres_q=0   # layer_num,  conv_idx_num
    if A_flag == 0:
        '''topk'''
        var_abs = torch.abs(DwR_1d)
        _,idx = torch.topk(var_abs, floor(sr*leng))
        '''mq '''
        value = DwR_1d[idx]
        value += res_q[idx]  # 采用q_res
        Nres_q = torch.zeros(leng).to("cuda:0")
        restored = torch.sign(value)*torch.mean(torch.abs(value))
        q_delta = value - restored
        Nres_q[idx] = q_delta
        value = [torch.mean(torch.abs(value)), torch.sign(value).type(torch.int8)]; timecost=[0,0]
    elif A_flag==1:     # rand k
        idx = torch.randint(high = leng, size = (floor(sr*leng),),device ="cuda:0")  # 快  重复(重复率低)
        # s = time.clock(); torch.randint(high = leng, size = (floor(sr*leng),));print('xxx',time.clock()-s)
        # s = time.clock();idx = torch.randperm(leng, device="cpu")[:ceil(sr * leng)];print('xxx',time.clock()-s)
        # s = time.clock();idx = torch.tensor(random.sample(list(range(leng)), floor(sr * leng)));print('xxx',time.clock()-s)
        value = DwR_1d[idx]*(1/sr)
        # value = sq(value)
        timecost=[0,0]
    elif A_flag==2:     # RB
        idx, value, meta, timecost = RB(splited_DwR,sr)
    elif A_flag==3:               # SmartIdx
        idx, value, meta, timecost = smartidx(DwR_1d,splited_DwR, sr,leng,chunk_idx,bb)
    elif A_flag ==5:
        params = {'compressor': 'topk', 'compress_ratio': sr, 'deepreduce': 'both', 'value': 'polyfit','index': 'bloom', 'policy': 'leftmost'}
        grc = deepreduce.deepreduce_from_params(params)
        idx,value,meta,timecost = grc.compressor.compress(DwR_1d, params['compress_ratio'])    #壓縮
        # tensor_decompressed = grc.compressor.decompress((value, idx[:meta[0]], idx[meta[0]:]), len(DwR_1d))  # 解壓縮
    elif A_flag == 6:
        DwR_1d = DwR_1d.cpu()
        var_abs = torch.abs(DwR_1d)
        _, keys = torch.topk(var_abs, floor(sr*DwR_1d.shape[0]), sorted=True)
        values = DwR_1d[keys]
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        value = skencode(values, keys, device)
        idx = torch.tensor([]).to(device)
        Nres_q = 0
        meta = 0
        timecost=[0,0]
    else:  # sbc
        idx, value,timecost = sbc(DwR_1d, sr, leng)  # sbc
    return idx, value, meta, Nres_q, timecost


def packing(idx,value, A_flag):
    if A_flag==5 : idx_byte = struct.pack(('%dB' % len(idx)), *idx)
    else:          idx_byte = struct.pack(('%dI' % len(idx)), *idx)
    if A_flag == 0:    #  randk/dgc
        value[0], value[1] = value[0].cpu().numpy(), value[1].cpu().numpy()
        value_byte = struct.pack('f', value[0]) + struct.pack(('%db' % len(value[1])), *value[1])
        coding_cost = 0
    elif A_flag==1:
        value_byte = struct.pack('%df' % len(value), *value)
        coding_cost=0
    elif A_flag==2:                  # ours
        st_list = value[0];     sign = value[1]
        sign = sign.cpu().numpy();  st_list = st_list.cpu().numpy()
        from Tobytes import tobytes
        length, value_byte = tobytes("/home/wdl/project/fedpipe/tobytestool.so", sign)
        value_byte = struct.pack('%df' % len(st_list), *st_list)+struct.pack('I', length)+value_byte
        # value_byte = struct.pack('%df' % len(st_list), *st_list) + struct.pack(('%db' % len(Tern_value)), *Tern_value)
        coding_cost= 0
    elif A_flag==3:      # SmartIdx：  mean(f)+length(I)+value_byte+idx_byte(%dI)+idx_len(I)
        s=time.clock();idx_byte = lzma.compress(idx_byte);coding_cost = round(time.clock()-s,3)
        len_idx = struct.pack('I', len(idx_byte))
        idx_byte+=len_idx
        mean, sign = value[0].cpu().numpy(), value[1].cpu().numpy()
        from Tobytes import tobytes
        length, value_byte = tobytes("/home/wdl/project/fedpipe/tobytestool.so", sign)
        value_byte = struct.pack('f' , mean) + struct.pack('I', length) + value_byte
        # value_byte = struct.pack('f', value[0]) + struct.pack(('%db' % len(value[1])), *value[1])
    elif A_flag == 5:
        value = value.cpu().numpy()
        value_byte = struct.pack('%df' % len(value), *value)
        coding_cost = 0
    elif A_flag == 6:
        idx_byte = b''
        value_byte = pickle.dumps(value)
        coding_cost=0
    else:                             # mean(f)+length(I)+value_byte+idx_byte(%dI)+idx_len(I)
        s=time.clock();idx_byte = lzma.compress(idx_byte); coding_cost =round(time.clock()-s,2)
        len_idx = struct.pack('I', len(idx_byte))
        idx_byte+=len_idx
        mean, sign = value[0].cpu().numpy(), value[1].cpu().numpy()
        from Tobytes import tobytes
        length, value_byte = tobytes("/home/wdl/project/fedpipe/tobytestool.so", sign)
        value_byte = struct.pack('f', mean) + struct.pack('I', length) + value_byte
        # value_byte = struct.pack('f', value[0]) + struct.pack(('%db' % len(value[1])), *value[1])
    return value_byte+idx_byte,coding_cost

def process(DwR_1d, leng, A_flag, sr, splited_delta,chunk_idx,res_q,bb):
    compress_cost,idx,Nres_q,coding_cost,residual = 0,0, 0,0,0; pack_cost,timecost,meta=[],[0,0],[]
    if sr!=1:
        s_comp = time.clock()
        idx,value,meta,Nres_q,timecost = compression(DwR_1d,leng,sr,A_flag,splited_delta,chunk_idx,res_q,bb)
        # if A_flag==2:
        #     tmp_idx = idx.cpu().numpy()
        #     residual= get_residual(DwR_1d,tmp_idx, meta, chunk_idx, bb,value[1], leng,num_layer,value[0])
        compress_cost = round(time.clock() - s_comp, 3)
        idx = idx.cpu().numpy()
        s_pack = time.clock();uploaded,coding_cost = packing(idx,value,A_flag);pack_cost = round(time.clock() - s_pack,2)
    else:
        value = DwR_1d.cpu().numpy()    # 完全不压缩
        s_pack = time.clock();uploaded = struct.pack(('%df' % len(value)), *value);pack_cost = round(time.clock() - s_pack,2)
    all_cost = [compress_cost, timecost[0],timecost[1],coding_cost, pack_cost]
    return uploaded,all_cost,idx, meta,Nres_q,value,residual


def comm(s,sr,s_flag,uploaded,idx,meta,DwR_1d,splited_DwR,residual,bb,chunk_idx):
    s.send(struct.pack('I', len(uploaded)))  # 先告诉服务器发送消息的总byte长度
    s.send(uploaded)  # 全部数据
    if int(sr) != 1:
        if s_flag == 0 or s_flag==4 or s_flag==6:  # top k
            residual = DwR_1d   # 残差积累
            residual[idx] = 0
        elif s_flag == 1:  # rand k
            s.send(struct.pack('f', 1 / sr))  # 告诉服务器conv layer的數量
            residual = DwR_1d  # 采用s_res
            residual[idx] -= (DwR_1d[idx] * (1 / sr))
            # residual[idx] = 0  # 残差积累
        elif s_flag == 3:  # SmartIdx
            s.send(struct.pack('I' , len(splited_DwR[0])))  # 告诉服务器conv layer的數量
            s.send(struct.pack('%dI' % int(len(meta[0])), *meta[0]))  # 告诉服务器每层有几个索引
            s.send(struct.pack('I', meta[1]))  # 告诉服务器前面多少个是卷积层索引
            idx = np.hstack((get_all(idx[:meta[1]], meta[0], chunk_idx,bb).cpu().numpy(), idx[meta[1]:]))
            residual = DwR_1d
            residual[idx] = 0  # 残差积累
        elif s_flag == 2 :  # RB
            s.send(struct.pack('I', len(idx)))  # 告诉服务器消息中 idx 的长度
            s.send(struct.pack('%dI' % int(len(meta)), *meta))  # 告诉服务器每层有几个索引
            # residual = DwR_1d   # 残差积累
            # residual[idx] = 0
        elif s_flag == 5:  # deepReduce
            s.send(struct.pack('%dI' % 2, *[meta[0],meta[1]]))  # 告诉服务器消息中 idx 的长度
            residual = DwR_1d   # 采用s_res
            residual[meta[2]] = 0  # 残差积累
    return residual





import pickle
from skcompress import *

def skencode(values, keys, device):
    is_display = False
    q = 128
    encoder = SKEncoder(values, keys, device)
    res = encoder.set_sign(mode='pos')
    if res:
        encoder.compress2index(q=q)
        encoder.minmaxsketch_insert()
        encoder.huffman_code(mode='hashtable', display=is_display)
        encoder.get_adaptive_prefix(interval_num=8, display=is_display)
        info_pos = encoder.transmit(display=is_display)
    else:
        info_pos = {}

    res = encoder.set_sign(mode='neg')
    if res:
        encoder.compress2index(q=q)
        encoder.minmaxsketch_insert()
        encoder.huffman_code(mode='hashtable', display=is_display)
        encoder.get_adaptive_prefix(interval_num=8, display=is_display)
        info_neg = encoder.transmit(display=False)
    else:
        info_neg = {}

    info = {
        'pos':info_pos,
        'neg':info_neg,
    }
    return info



"""RB2（交換量化和稀疏化的順序）"""

# def RB2(splited_DwR,sr):
#     st_list_q=[]; st_list_s=[]; selected_block=[];selected_bias=[]; block_idx = []; layer_block_num=[]; bi_list = []
#     for i,block_layer in enumerate(splited_DwR[0]+splited_DwR[1]):
#         ''' 随机稀疏化'''
#         sparse_Idx = torch.randperm(len(block_layer), device="cuda:0")[:ceil(sr * len(block_layer))]
#         sparse_Idx, _ = torch.sort(sparse_Idx)
#         block_idx.append(sparse_Idx)
#         selected_block.append(block_layer[sparse_Idx])
#         selected_bias.append(splited_DwR[2][i][sparse_Idx])
#         st_list_s.append(1 / (len(sparse_Idx) / len(block_layer)))
#         layer_block_num.append(len(sparse_Idx))
#         ''' 随机量化'''
#         norm_list = torch.norm(torch.abs(block_layer[sparse_Idx]), dim=1,p=2)
#         s_t =  torch.max(norm_list);      st_list_q.append(0.05*s_t/np.sqrt( block_layer.shape[1]))
#         prob_1 =  norm_list / s_t
#         prob_0 = 1 - prob_1
#         prob = torch.t(torch.vstack((prob_0, prob_1)))
#         bi = list(WeightedRandomSampler(prob, 1))
#         bi = torch.tensor(np.reshape(bi, [len(bi), ]),device="cuda:0")
#         bi_list.append(bi)
#     '''获取实际上传索引'''
#     idx_1d = torch.cat((block_idx[0], block_idx[1]), 0)
#     for j in range(2, len(block_idx)):
#         idx_1d = torch.cat((idx_1d, block_idx[j]), dim=0)
#     '''获取实际上传参数值'''
#     selected_param = list(chain.from_iterable(zip(selected_block, selected_bias)))
#     bi_list = list(chain.from_iterable(zip(bi_list, bi_list)))
#     selected_param_sign=[]
#     for i,item in enumerate(selected_param):
#         for j,tensor in enumerate(item):
#             selected_param_sign.append(torch.sign(tensor*bi_list[i][j]))
#     st_list = st_list_s*np.array(st_list_q)
#     st_list = list(chain.from_iterable(zip(st_list, st_list)))
#
#     value_1d = torch.cat((torch.flatten(selected_param_sign[0]), torch.flatten(selected_param_sign[1])), 0)
#     for j in range(2, len(selected_param_sign)):
#         value_1d = torch.cat((value_1d, torch.flatten(selected_param_sign[j])), dim=0)
#
#     value_1d = value_1d.type(torch.int8)
#     st_list = torch.tensor(st_list, device="cuda:0")
#     return idx_1d,[st_list,value_1d],layer_block_num



# def RB(splited_DwR,sr):
#     st_list_q=[]; st_list_s=[]; st_list=[]; selected_block=[];selected_bias=[]; block_idx = []; layer_block_num=[]
#     q_time = []; s_time = [];non_zero = []; non_zero_num = 0; total_tensor_num = 0
#     for i,block_layer in enumerate(splited_DwR[0]+splited_DwR[1]):
#         block_idx.append([]);selected_block.append([]);selected_bias.append([])
#         total_tensor_num+=len(block_layer)
#         '''第一次随机量化'''
#         s_quan = time.clock()
#         norm_list = torch.norm(torch.abs(block_layer), dim=1,p=2)
#         s_t = torch.max(norm_list);      st_list_q.append(s_t/np.sqrt(block_layer.shape[1]))
#         prob_1 = norm_list / s_t
#         prob_0 = 1 - prob_1
#         prob = torch.t(torch.vstack((prob_0, prob_1)))
#         bi = list(WeightedRandomSampler(prob, 1))
#         bi = torch.tensor(np.reshape(bi, [len(bi), ]),device="cpu")
#         tmp = torch.where(bi > 0)[0]
#         for x in tmp:
#               non_zero.append([i,x])
#         q_time.append(time.clock()-s_quan)
#     '''第二次随机稀疏化'''
#     s_sp = time.clock()
#     IdxOfIdx = torch.randperm(len(non_zero),device="cpu")[:ceil(sr * total_tensor_num)]
#     st_sp= len(non_zero)/(sr * total_tensor_num)
#     st_list = st_sp*st_list_q
#     idx_tuple = np.array(non_zero)[IdxOfIdx]
#     for itm in idx_tuple:
#         block_idx[itm[0]].append(itm[1])
#         selected_block[itm[0]].append((splited_DwR[0] + splited_DwR[1])[itm[0]][itm[1]])
#         tmp_b = []
#         for bias in splited_DwR[2][itm[0]]:
#             tmp_b.append(bias[itm[1]])
#         selected_bias[itm[0]].append(tmp_b)
#     for j in idx_tuple:
#         layer_block_num.append(len(j))
#     s_time.append(time.clock()-s_sp)
#     s_cost = round(sum(s_time),4);q_cost = round(sum(q_time),2)
#     '''获取实际上传索引 1d'''
#     idx_1d = chain.from_iterable(block_idx)
#     '''获取实际上传参数值 1d'''
#     selected_param = list(chain.from_iterable(zip(selected_block, selected_bias)))
#     selected_param_sign=[]
#     for item in selected_param:
#         if isinstance(item,list)==1:
#             for it in item:
#                 selected_param_sign.append(torch.sign(it))   #  bias   bn
#         else:
#             selected_param_sign.append(torch.sign(item))     #  tensor
#     # st_list = st_list_s*np.array(st_list_q)
#     # st_list = list(chain.from_iterable(zip(st_list, st_list)))  # 只適合無bn層的網絡（舊版本）
#
#     value_1d = torch.cat((torch.flatten(selected_param_sign[0]), torch.flatten(selected_param_sign[1])), 0)
#     for j in range(2, len(selected_param_sign)):
#         value_1d = torch.cat((value_1d, torch.flatten(selected_param_sign[j])), dim=0)
#
#     value_1d = value_1d.type(torch.int8)
#     st_list = torch.tensor(st_list, device="cuda:0")
#     return idx_1d,[st_list,value_1d,st_list_s],layer_block_num,[s_cost,q_cost]